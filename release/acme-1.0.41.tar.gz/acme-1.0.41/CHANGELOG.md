# Changes in acme

Newest first. Each version's section is what the pages show before an
upgrade (and, going back, what is given up), so it says what changed for
the people who run acme - one `## X.Y.Z - date` heading per version.

## 1.0.41 - 2026-11-04

- **Six more pictures for the sign-in** (*Settings → The enrolment pages → The picture
  on the sign-in*, for the enrolment pages and the administration each), of
  certificates and their automation, drawn as the four there were (in the page's own
  colours, nothing fetched, the same size, still with reduced motion): *An ACME
  order, step by step* (ordered, the challenge, proved, issued), *The name proved in
  the DNS* (the `_acme-challenge` TXT record looked up by the authority, no port
  opened), *The key, the request, the signature* (the private key never leaves the
  server), *What the servers serve, looked at again and again* (the name, the chain,
  the days left), *Revoked and replaced* (a new key, put in place) and *The next one
  long before the last runs out* (never a gap). In Czech too.
- **Pictures of their own for each sign-in**: five more for the enrolment pages only,
  as the people who ask for certificates see it - *Asked for on the pages, approved,
  issued to you*, *Your certificate, downloaded as your server takes it* (PEM, PFX, the
  chain), *Your certificates, and how long each one has* (and a mail before one runs
  out), *Your password, then a code by mail or SMS*, *Your team's certificates* - and
  five for the administration only, as those who run acme see it - *Everything at a
  glance*, *Two nodes, one address, one database*, *Every authority, into one place*,
  *The jobs, by themselves and on time*, *Every change written down, every failure
  told*. Each tab of the picker offers the fifteen drawings that may go on its sign-in
  (the ten above for both, and its own five); the other sign-in's own are refused when
  saved, and one in an imported configuration is put in as that sign-in's default.
- *Settings → High security*: under *High security* and *Guard against writes to the
  database*, a light for every node saying what is in effect there - on (green), off,
  not there yet / still on after a change (amber, looked at again every few seconds),
  the guard on with rows refused (amber) or with no key to check them (red), a node not
  heard from (red). The guard is each node's own: the light says where it is still off.
  In a cluster only (both nodes, a line each); standalone the switch says it all.
- *Local users*: a user made, changed or taken away is in *SSH keys → Whose keys* at once
  - it was there only after reloading the page (F5).
- *Local users*: the windows have on/off switches, as every other page, where they had
  check boxes (to be changed at the first sign-in, sudo, the nodes, the home folder too).

- **`acme --get KEY`**, the counterpart of `--set`: one setting's value alone (for a
  script), again for more (`KEY=VALUE` a line, as `--set` takes them), `--json` as
  `{key: value}`. A secret shown hidden, as `--settings` shows it; a key that is no
  setting refused, nothing printed.

- *acme's gate for SSH: the port tried first* was shown under every pane of Settings
  (the page had no place for it): now only under *SSH server and notices*, in a card
  of its own (*acme's gate for SSH*), as otp has it. A test now sees that every pane's
  settings have their place on the page.

## 1.0.40 - 2026-11-04

Taken over from otp 1.0.230-1.0.243: everything of those versions that is not about RADIUS, the
tokens or the enrolment of otp - the local users of the machines, the SSH keys of every user,
SELinux, the guard against writes to the database, behind a load balancer and signed in by it,
wrong directory passwords per person, the alerts of everything the nodes see, and otp's two bug
hunts. Every new switch is off - as until now - unless said otherwise.

- **Local users of the machines** (*Settings → Local users*, full administrators; as otp 1.0.243).
  The users of each node's own system, one row a user and a column a node: made, given a
  password, sudo (wheel / sudo), locked (the password and the account - no SSH key lets them in
  either) or unlocked, their full name and shell changed, taken away with or without the home
  folder - on every node of a cluster at once or on the ones ticked, the same UID on each; a user
  on one node only made on the others with a click. **root is shown only**, never changed from
  the pages (the API refuses it); accounts of the system and of the services (acme, acme-web,
  postgres, mysql, nginx, sshd…) are neither shown nor changed - by the daemon and by the root
  helper both. A password typed on the page goes to the nodes as its sealed SHA-512 hash only,
  to `chpasswd -e` on its standard input, and is taken out of the database once done (after 15
  minutes in any case). Also `acme --local-users`, `acme --local-user
  add|password|lock|unlock|sudo-on|sudo-off|drop|drop-home NAME` (a password asked at the
  terminal, never on the command line) and four items in `acme --console`. See
  docs/local-users.md.
- **SSH keys of every user who may sign in** (*Settings → SSH keys*, was *SSH keys of root*; as
  otp 1.0.240). *Whose keys*: root as until now, or any normal user of the nodes (UID 1000 and
  up, a login shell) - their own `~/.ssh/authorized_keys` read from every node, a key added, made
  here (the private half shown once, kept nowhere), exported or taken away, on the nodes where
  the user is. Read and written **as that user** by a child of the root helper with their UID,
  GID and groups: `~/.ssh` 0700 and the file 0600, theirs; a link in their home is refused and
  never followed. Every change in Events with the user's name. docs/ssh-keys.md.
- **The console at login for normal users too** (*Settings → About → The console at login*:
  *normal users: nobody / every one / these…*; `acme --console-users "alice bob"`, `'*'` or
  `none`; on the console under The service). Off by default - root only, as until now. Named
  users land in the console **through sudo, with their own password**: only who may become root
  with sudo gets it; anybody else named gets one line saying so and the ordinary shell. What is
  done from such a console is in Events as `command line (sudo alice)`.
  `/etc/acme-console-login` gets a second line (`users: …`); root's own switch is kept apart.
  docs/console.md.
- **Accounts picked, not typed** (*SSH server and notices → Who may sign in*, *About → the
  console at login's normal users*; as otp 1.0.242): lists of the accounts of the nodes - root
  and every user who may sign in there - several at once, or everybody (nobody / every normal
  user for the console); chips to take one away, a search when the list is long. One set before
  that the nodes do not list (a pattern of sshd's) stays, said so.
- **A key shown once, shown big**: Prometheus's token, made on *Monitoring*, is in a large box
  across the dialog, picked whole with one click, with Copy beside it (as otp 1.0.240).
- **Behind a load balancer or WAF** (*Settings → Firewall and access*; off by default - nginx as
  until now; as otp 1.0.237 and 1.0.238). Switched on, nginx takes the client's own address from
  the header the balancer sends (`X-Forwarded-For`, or the one named: `X-Real-IP`,
  `True-Client-IP`...) - only for requests from the balancers' addresses named, never anybody
  else's - so that the sign-in pause, the caps, who may reach which page, nginx's limits and every
  log see the client, not the balancer. In this node's server and the VIP address's, on every
  node, through the root helper (`nginx -t`, put back when refused). It takes the place of what
  `acme --trusted-proxy` wrote while on; off, only its own lines go - the 0 kept as a row of its
  own, so that "switched off" is not read as "never switched on". Refused on without the
  balancers named; `acme --trusted-proxy` refuses while it is set on the pages.
  docs/load-balancers.md.
- **Signed in by a load balancer or WAF (SSO)** on the certificate portal (*Settings → The
  enrolment pages*; off by default - the portal as until now; as otp 1.0.239). The portal
  published to the internet through a NetScaler, an F5 APM or another balancer that signs people
  in against the directory first: who it signed in comes in a header (`X-Acme-User`, or one
  named), and the portal asks no password again. Believed only on a connection from the
  balancers named - the machine the request really came from (nginx's `$realip_remote_addr`,
  passed to the page as `ACME_PEER`), never the client's address from `X-Forwarded-For` - and
  only with the key in `X-Acme-Sso-Key` (made on the pages or with `acme --sso-key`, shown once
  in a large box, kept sealed, compared in constant time). Everything after the password as it
  was: the portal's directory asked who it is, *Who may sign in* decides. The same person on the
  next page goes on in the same sign-in, another one on the same browser ends it; switched off,
  a sign-in by the balancer ends. *Sign out* goes to the balancer's own sign-out when one is set,
  or holds the sign-in by the balancer until asked again. Every refusal in *Events* with its
  reason, and - for who wants it - mailed (*Alerts and reports → Sign-ins by the load balancer
  refused*, off by default). The card shows the last sign-in by the balancer each node saw and -
  switched on - the configuration of NetScaler (nFactor/LDAP, rewrite of the headers, `/admin`
  dropped, the Web App Firewall), F5 APM (access profile, iRule) and nginx / oauth2-proxy,
  filled in with this server's values, with Copy buttons. Each node's root helper adds one line
  to the portal's `location = /` (checked with `nginx -t`); off, only that line goes. The
  administration pages are not concerned. `acme --sso-status`, `acme --sso-key`; in the console
  under *Encryption, sending out, time, network, high security*. docs/portal-sso.md.
- **The VIP address no longer lost for good when its name was taken away** (as otp 1.0.242).
  With a certificate of the VIP address's own kept and its name (*FQDN*) emptied afterwards,
  each node's root helper refused the whole request ("a certificate of its own needs the name it
  is for") - and no change of nginx, keepalived or the firewall reached the node again. The
  node's certificate now serves the address until a name is given again (said in the log); given
  a name, its own certificate is back on it. A part of nginx the helper cannot put in (the
  balancer's lines above) is said and holds up nothing else of the request either.
- **Dual certificates in and out of acme's own TLS** (*Settings → TLS and the VIP address*; as
  otp 1.0.240): an RSA and an ECDSA certificate of the same names uploaded together - both keys
  in the PEM, two PFX files, or one of each; on the command line `acme --tls-import rsa.pfx
  ecdsa.pfx` - are both put in, the RSA one the main and the ECDSA one beside it, as ACME's
  "both" keeps them (nginx gives each client the one it takes). One alone is as until now, and a
  second one there before is dropped. Two RSA, other names or a key without its certificate are
  refused. *Download* of such a certificate asks which: RSA, ECDSA, or both (a .zip of the two in
  the format chosen - not only PEM as before - each key locked with the password); in Events
  which and with what.
- **SELinux** (*Settings → High security → SELinux*, a card for each node; `acme --selinux-check`),
  as in otp 1.0.233-1.0.238. Nothing changes unless asked: a machine with SELinux disabled stays so,
  and acme runs on it as before.
  - acme's module `acme_server` (`deploy/acme_server.cil`): the labels of `/run/acme` **and**
    `/var/run/acme` and the API token as the web server's own run files, so the pages (php-fpm,
    `httpd_t`) can read the token under enforcing; and one narrow rule - systemd may change the
    owner and mode of what is in `/run/acme` before every command of the unit (`systemctl reload
    acme` too). Put in by install.sh and every upgrade where SELinux is on (only when it changed,
    compared with the one last put in), taken out by `--uninstall`. The tools (`policycoreutils`,
    `libselinux-utils`, `policycoreutils-python-utils`, `audit`, `selinux-policy-targeted`) put in
    where missing on RHEL, Rocky and AlmaLinux - the mode is not touched - and auditd started
    where SELinux is on.
  - The card: the mode now and after a restart, the module, the labels of acme's files, the boolean
    (`httpd_can_network_connect`) and ports (sshd's own, a local PostgreSQL's) acme needs, and what
    SELinux refused since the machine started, grouped and counted - only since acme's needs were
    last put in, and not what the policy loaded now allows (`audit2why`: *refused before, allowed
    now*). auditd not running is said, and enforcing refused. Looked at two minutes after the
    start and every half hour (at the lowest priority), and on *Look again*.
  - The steps, each asked of one node and done by its root helper: *Make it ready (permissive)* -
    the configuration, every file labelled at the next start, `selinux=0` off the kernel's command
    line, the module; the machine is not restarted. *Put in what acme needs*. *Switch to
    enforcing* - from permissive only, with nothing missing and nothing refused. *Back to
    permissive*. Each in Events.
  - *Download the report (all nodes)* (`acme --selinux-report`): every node gathers what SELinux
    says there - what it refused (raw, readable, `audit2why`, `audit2allow`'s suggestion), the
    labels and what the policy says they should be, domains, ports, booleans, versions, what acme
    uses on the node (nothing secret) - in one file; nothing is changed to make it, kept sealed in
    the database an hour. Sent on, it becomes rules of `acme_server`.
  - The security check lists what keeps a node where SELinux is on from being protected; the
    alert *SELinux refusing* (`alerts_selinux`, off by default) mails it.
  - `acme --selinux check|prepare|apply|enforce|permissive` (asked first unless `--yes`), and the
    console (*Encryption, sending out, time, network, high security*). docs/selinux.md.
- **Root's actions only from rows acme signed - the guard against writes to the database**
  (*Settings → High security → Guard against writes to the database*, `db_guard`; off by
  default - as until now; from otp 1.0.231-1.0.236). What a node does as root - the firewall,
  sshd and root's SSH keys, the network, a restart, the system's updates and their proxy, the
  time servers, nginx's certificates, the VIP, the TLS of the database link - follows rows of
  the database, and so do the accounts and sign-ins of these pages. Anybody who could write the
  database (its server, a db_password found out, a copy put back) could have had the node do any
  of it.
  - Every such row is signed when acme writes it - an HMAC with a key from secrets.key, in no
    database - in a row of its own beside it (`sig:<kind>:<hash>:<node>`; each node writes only
    its own), in one transaction with the row.
  - On: a sign-in, an account, the administrators' directory, a setting that reaches root, a row
    of meta root acts on, another node's heartbeat - not written by acme, or an older one put
    back - is not acted on; settings keep their last good value. Said in the log, in Events and
    in the security check. The certificates, renewals and deployments are never held up by it.
  - Kept in this node's config.json, not in the database; switched off only on the node itself,
    taken by the running service at once (`acme --set db_guard=1`). A copy put back, an import,
    the database moved and a node renamed are signed again afterwards; a node rebuilt from the
    other only forgets what it had seen. Going back below 1.0.40 is refused while it is on on any
    node. `acme --guard-status` (and on the console under high security) lists every row that
    reaches root not as acme wrote it. docs/high-security.md.
- **`systemctl reload acme` took the pages off the node** (as otp 1.0.232): systemd gives
  `/run/acme` back to `acme:acme` before a reload; the pages could not read the API token,
  `/healthz` said 503 and keepalived moved the VIP address away. The daemon gives `/run/acme` and
  the token back to `acme-web` the moment the reload arrives, and checks it every 5 seconds.
- A change of the settings made on the other node while this one was reading its own was missed
  until the next change: the mark of the change is read before the settings now (otp 1.0.234).
- **Bug hunts A and B of otp (1.0.234-1.0.235), carried over:**
  - **The VIP address switched off by a name not answered**: with `ha_peer` (or `ha_address`) a
    host name and DNS away for a moment, the node stopped keepalived and took its configuration
    away. It goes on with the addresses last known now; a name not answered is asked again in
    half a minute. Its database gone, the node says so to keepalived at once.
  - **A change of sshd on trial** whose time ran out while the machine restarted was kept for
    good: its timer does not outlive a restart. The root helper puts it back at its next run;
    the timer is armed before the change goes in.
  - **SSH on another service's port** (443, 5432, 53…) refused - sshd could not bind it and
    stopped.
  - **Moving into another database**: what was written while it was carried, or after - a
    certificate added, a password changed - was left behind, and *Start using it* did not see it.
    It compares the certificates, their versions, sources, validations, targets, deployments,
    tests, DNS, teams, tags, profiles, accounts, settings and directories now, and refuses an older
    copy. The codes of the administrators' app used meanwhile stay used, there and when a copy is
    put back.
  - **Backups to other machines**: room for them checked first (twice the database); an unlocked
    archive fetched from a destination refused even where no password is in play; the weekly check reads the newest
    *nightly* copy (it read the hand-made ones, and passed with nothing read); locking or opening
    a large one is not cut off after two minutes.
  - **acme's own certificate by ACME**: two nodes with the manual DNS step take turns instead of
    cancelling each other; any failure of an order is written down.
  - **Mail**: a code being sent is not taken back for another try before one try can have ended
    (it went out twice), nor tried in its last half minute; a redirect to another host does not
    carry the gateway's credentials; the weekly or monthly report missed on its day goes on a
    later day of the period.
  - Smaller: the SNMPv3 count of starts written whole (cut short, it went back); a time zone or
    interface name that reads as an option refused; a sign-in that counted twice in one request
    gives both places back; a node stopped half way through a write no longer holds its rows on
    a database server for hours.
- **A code typed as the mail shows it** (as otp 1.0.224-1.0.227): the administrators' second
  step takes "821 275", "821-275" or any dash, a no-break space, full-width digits and the top
  row of a Czech keyboard without Shift; a 10-digit code is no longer cut short in its box.
- **Wrong directory passwords per person capped** (*Settings → Sign-in protection → Wrong
  directory passwords per person*, `dir_pw_tries`; 0 by default - as until now), as
  otp 1.0.230 - 1.0.234. A directory password is tried against Active Directory at
  each sign-in to the enrolment pages (the certificate portal) and at each sign-in of
  an administrator from the directory - each with a count of its own, on each node
  alone: from many addresses, enough wrong ones for a name reached the directory to
  lock the account there. Set below the directory's lockout threshold (3 for 5 to
  10): after so many wrong passwords for one person within `dir_pw_window_min` (30
  min), from anywhere, on any node, the directory is no longer asked for them - only
  the pages wait, the account in Active Directory stays unlocked.
  - Counted **by the account the directory resolves**, not by the name typed:
    `novakj`, `jan.novak@corp.cz` and `CORP\novakj` are one count. A name the
    directory lacks - or an account switched off, locked or answered twice - is held
    back the same way, so the answer does not tell which names exist. A right
    password does not count, nor one never asked of the directory (empty, with a
    control character); the address's own count keeps its place too. One count for
    the cluster, in the database.
  - **Each directory** on a card of its own (*Wrong directory passwords - each
    directory*): *As the setting above*, *Its own* (a cap and a window for it alone)
    or *No cap*. A directory renamed keeps its cap, one taken away takes it with it.
  - **Read the domain's policy** (full administrators) connects with the
    directory's own account and shows the domain's *Account lockout*, *Password
    policy* and every *Fine-grained password policy* it may read, and recommends a
    cap below the lowest threshold over the longest window. *Use it* only fills it
    in - nothing changes until *Save the changes*.
  - Shown and cleared under *Locked out*. `acme --dir-caps`,
    `acme --dir-cap NAME=3/30|setting|none`, `acme --dir-policy NAME`; on the
    console under *Directories*. docs/sign-in-protection.md says all of it.
  - The card of a directory: its two sections side by side, of the same width,
    across the whole width - a third, empty column left them narrow.
- **Alerts for what the nodes already see** (*Alerts and reports*), as otp
  1.0.242 - mailed now, each with a switch of its own, on by default: the key that
  opens the sealed secrets missing on a node and two nodes under one name (under *A
  node down*); **logs not reaching isemon or the syslog servers** (with the lines
  dropped); **the SNMP agent not listening** or its traps not going; **a certificate
  of a node or of the VIP address the CA did not renew** - at once, not only once it
  is about to run out (the certificates the certificate manager keeps are said by
  it, as before); the certificates of **PostgreSQL's TLS and the link between the
  nodes** running out (with *A certificate running out within*); **the update of
  the system failed**, or a node that cannot look for updates; **an upgrade of acme
  that failed**; **a change on trial that went back** (the network, the firewall,
  the SSH server - the network's going back is in Events now too); **rows of the
  database not written by acme** refused (the guard against writes); **mails with a
  code or a notice of certificates that do not go**; a clock out of sync on a node
  without chrony. Off by default, for who wants them: the replication behind by more
  than N MB, SELinux, the security check, each sign-in by the load balancer
  refused. *The nodes apart* and *the clock guard* have switches of their own too
  (on, as they were). Fixed on the way: with no event at all when the alerts first
  looked, what happened later was never mailed.
- **The alerts in a cluster** (as otp 1.0.234): "quiet while a node is worked on"
  was one row both nodes wrote - two first rows at once stop the replication; each
  node writes its own now. A test alert or *Forget* on the node that does not send
  no longer writes back an older copy of what was sent (the same alerts again).
  The weekly or monthly report missed on its day goes on a later day of the period.

- **Sign-in protection** (*Settings → Sign-in protection*, as otp's pane). **Block a place that
  keeps guessing** (`login_guard`; off by default - as until now): the sign-ins to these pages and
  to the certificate portal counted by the address they come from too; too many refusals from
  one place, or too many different names refused from it, and it is blocked for a while
  (`login_guard_tries`, `_names`, `_window_min`, `_block_min`; `login_guard_trusted` never
  blocked) - its sign-ins refused at once, no directory asked. With it: the cap of wrong
  directory passwords per person (one switch for the guessing guards, as otp 1.0.241), each directory's own cap with *Read the domain's policy*, and
  *Counted and blocked now* - the sign-ins to these pages and the portal, the codes sent and the
  names held back, with a filter and *Clear*. For every directory set in *Accounts → The
  directories administrators sign in against*: the administrators' sign-ins and the portal's.
- **Where a person's e-mail address and mobile number are read from the directory - on each
  directory's card** (*Settings → Accounts → The directories administrators sign in against →
  edit*, *A person's e-mail and mobile number*; as otp 1.0.229). As until now by default: `mail`,
  and `mobile` with `telephoneNumber` when that is empty. Any attribute, or several in order (the
  first with a value is taken); `proxyAddresses` read as Exchange keeps it (the primary SMTP:
  address). Used for the codes by e-mail and SMS and for what the portal knows of a person.
  *Show a person's attributes*: the whole entry of one person, from the card as it is now (saved
  or not), with what the boxes would read, the attributes that can hold an e-mail address and
  those that can hold a phone number each with *Use*, and every attribute of the entry listed. A
  full administrator only; written into Events. `acme --dir-sample NAME USER`, and on the console.
- **A one-time code at every sign-in to the certificate portal** (*Settings → The enrolment
  pages → A one-time code at every sign-in*, `portal_code`; off by default - as until now): a
  person of the directory signs in with their name and password - or is signed in by the load
  balancer in front (SSO) - and a code goes to the e-mail address or the mobile number the
  directory has for them (read where the directory's card says), at **every** sign-in, not only
  the first as otp has it. Until it is typed nothing else can be done and nothing of the person
  is shown. The page as otp's: where the code went (masked), the box, *Confirm*, *Send it again*
  and *Back*; pasted as the mail or the SMS has it ("482 913"). By e-mail, by SMS, or one with
  the other where the directory lacks it; saved only with the mail or the SMS gateway set up.
  Its own words in *Settings → Message texts* (a mail and an SMS). Each code sent, each wrong one,
  the sign-in with it in Events - never the code. The portal's own accounts keep their second
  step as before.

- **Signing in over SSH with a code from acme** (*Settings → SSH server and notices →
  Signing in with a code from acme*; off by default - as until now), as otp 1.0.178 -
  1.0.243. sshd of every node asks for a code where it would ask for the account's
  password: `pam_radius` asks a small gate of the acme daemon on 127.0.0.1 of that
  node (a port of 18129-18199 each node finds for itself, a long secret of its own,
  sealed), so a node alone still lets you in. The gate understands only what
  pam_radius sends (an Access-Request with User-Name, User-Password,
  Message-Authenticator and State) and answers nothing from elsewhere or signed with
  another secret. Needs *acme sets the SSH server*; put in on trial like every change
  there, checked with `sshd -t` first, and put back by itself unless kept.
  - *Only these accounts* (picked from the accounts of the nodes; none: *Everybody but
    root (unless Root too)*), *Root too*, *A key, and then the code*
    (`AuthenticationMethods publickey,keyboard-interactive` for those asked; root with
    a key only gets a `Match User root` block of its own), *The system password when
    acme does not answer* (`localifdown`, only with passwords on) and *Hide the code as
    it is typed* (echo off).
  - **SSH tokens**, a list of their own under the card (*Account, Note, The codes, Made,
    Last used*; *A new one…*, *Remove*; *Add an SSH token…*): one for each account of
    the nodes - root, or a user who may sign in there; one that has a token is not
    offered, and the daemon checks the name again. Codes **from an app** (the QR code
    and the key shown once), or **sent by mail or SMS** where sending is set up, in
    Czech or English (*Settings → Message texts → SSH: a sign-in code by mail / by
    SMS*). One prompt, no `Password:` first; a wrong code asked again three times; a
    code good once on either node; five wrong ones for a name in five minutes and it
    is refused for five minutes; a code by mail or SMS at most every 20 s and five in
    15 minutes per account. Every sign-in and every wrong code is an event (*ssh*),
    never with the code in it.
  - The root helper writes only `127.0.0.1` and a port of 18129-18199 into
    `/etc/acme/pam_radius.conf` (0600), its own block into `/etc/pam.d/sshd` between
    two marker lines (taken out whole when switched off), installs `pam_radius` where
    it is missing (RHEL: from EPEL) and turns SELinux's `authlogin_radius` on;
    *Settings → SELinux* lists it and the gate's port (`radius_port_t`, UDP
    18129-18199 only).
  - High security: with the code asked and no system password when acme does not
    answer, keyboard-interactive is no longer counted as a password sign-in, nor
    root's own block as root signing in with a password (as otp 1.0.242).
  - Each node's card says whether pam_radius asks for the code and where the gate
    listens - otp read it from where it is not, and showed "–" always.
  - Also `acme --ssh-tokens`, `acme --ssh-token-add NAME [--by mail|sms --to …]
    [--no-qr] [--invert]`, `acme --ssh-token-del NAME` and three items in
    `acme --console`. See docs/ssh-with-a-code.md.
  - *Settings → Message texts → SSH: what it asks for the code*: what ssh shows when it
    asks for the code - by mail, by SMS, from the app, and a wrong code asked again - in
    Czech and English, each shown in a terminal's window with its size (at most 253 bytes,
    as RADIUS carries it; longer or empty is refused when saved).

## 1.0.39 - 2026-11-04

- The nightly dumps of the database were never seen: they are called
  acme-ENGINE-..., and only the names of otp (otp-, opt-) were taken. So
  the card The database on Overview counted only the copies made by hand
  or before an upgrade and turned yellow ("last copy 3 days ago") beside a
  dump of last night; Settings → The database did not list them, they could
  not be downloaded, and they were never kept to "Copies kept" - they piled
  up. Now they are counted, listed, downloadable, and the oldest go once
  there are more than "Copies kept" (at the next night's dump).
- The card The database says why it is not green, under its number and at
  the top of its popup: no copy every day, the last one failed (and what it
  said), made by the other node of a cluster on one database, the first one
  still to come, or late - with when the last one was made and when the
  next one is due. Its list of copies has the nightly dumps in it too.

## 1.0.38 - 2026-11-03

- A popup over another one - what the server served, What happens, Export,
  Import and the rest - no longer throws the one underneath back to its top
  when it is closed: it stays scrolled where it was, also while its parts are
  asked for again. A popup opened afresh still opens at its top.

## 1.0.37 - 2026-11-03

- What happens records what a module does on its own too, not through acme's
  Context: HTTP over http.client or urllib (MS AD CS, a module of your own) -
  each request whole, its proxy said; FTP and FTPS over ftplib (the HTTP-01 over
  FTP validation) - the connection, whether the server's certificate is checked,
  every command (PASS ••••), each upload with its size; a socket of its own - UDP
  with every byte it sends (SNMP, say), TCP with where it connects (what it says
  there cannot be told). Still nothing is reached.
- What happens, with its debug details: bytes taken apart as Wireshark shows a
  packet (acmelib/certs/dissect.py) - each field named, its value read and said
  (flags one by one), the bytes it comes from; the bytes under it, the ones of
  the field pointed at lit up. What the tests send before TLS: LDAP's StartTLS
  (BER), PostgreSQL's and MySQL's SSLRequest (its capability flags), TDS
  PRELOGIN (its options), RDP's TPKT / X.224 / RDP_NEG_REQ (the protocols asked
  for); what a module sends over UDP: SNMP (BER: version, PDU, varbinds - the
  community, a password in effect, never shown), DNS (header flags, questions),
  syslog (priority). A packet cut short: what could be read, then said so.
- What happens: *Show debug details* (off by default, kept in the browser). Off,
  the page is as it was - the headers a module sets, the steps of a test in
  short; on, everything below: each request as it goes on the wire, how each
  connection is made, the ssh command with its options, a test's every fact.
  The other steps' facts too: the TLS handshake after a deployment (its
  address, SNI, the key asked for, how it is compared), a DNS question (its
  servers, port, transport), a command run here (as whom, in which folder, its
  variables, no shell).

- What happens shows each HTTP request as it goes on the wire: the request line,
  every header in the order sent - the ones acme and Python add (Accept-Encoding,
  Content-Length, Host, Content-Type, User-Agent, Connection) dimmed - and the
  body as sent; *Copy the whole request*. Above it how it is connected: the
  address and port, TLS, the name sent as SNI (none to an address), how the
  device's certificate is checked (this machine's CAs, the CA set, or not at
  all), a client certificate, the proxy, the time limit. Secrets left out as
  before (a password, a token, a header that signs in: ••••). A module of your
  own, never seen here, is shown the same: what it really sends, recorded.
- What happens over SSH: the ssh command as it runs, every option (the host key
  checked against the one kept, its time limits, how it signs in, BatchMode)
  - its temporary files said, a password never in it - folded under the
  connection's facts; the options made in one place for the connection and the
  plan (runtime.ssh_options). A DNS UPDATE: its server, port, transport and
  TSIG key's name (not the key).
- What happens for a test: the connection (address, port, address family, from
  the address, time limit), what it says before TLS line by line (SMTP's EHLO and
  STARTTLS, IMAP, POP3, FTP, XMPP; the bytes of LDAP, PostgreSQL, MySQL, TDS and
  RDP's start), the ClientHello's settings (SNI, TLS versions, ciphers, ALPN, the
  key asked for - both: two connections), and an HTTPS test's request whole, its
  headers too (Authorization, Cookie and API keys: ••••); what counts as right
  (the version, the name it must hold, trust, the days before its end, the HTTP
  status and words). A test's talk() is held to what it really sends by
  test/test_checks_protocols.py; a test of your own without one is said so.

## 1.0.36 - 2026-11-03

- Tests: *Key asked for: both* - connected twice, once for RSA and once for
  ECDSA, each judged and drawn side by side (the half of acme's certificate it is
  set against only); the worse of the two is the result, the job's log and the
  mail say each. A result says what counted as right (*Expected*), and the half
  of acme's certificate set against what was sent is drawn first - the card of
  what was sent beside it, not below the other half.

- Settings → Upgrades → *Look now* just after a release found nothing new:
  raw.githubusercontent.com keeps a branch's index.json 5 minutes (and an
  address with ?anything does not get past it). The look asks GitHub's API for
  the branch's newest commit (one question) and reads the index of that commit,
  an address that never goes stale; where the API does not answer, the branch's
  index as before.

## 1.0.35 - 2026-11-03

- Two files of your own saying the same kind and version (an upload of
  `netscaler_14_1 (1).py` beside `netscaler_14_1.py`, say): the module's window
  says which is used (the later by name) and which not, with *Take the unused
  one away* - it was silent. `shadowed` in `GET /api/plugins` and
  `/api/modules`.

- Modules → a module → *Make it the default* on any of its versions: what every
  source, validation, target or test that names no version uses - kept in the
  database (both nodes, every backup), over `default_version` in the code; the
  window says first how many follow it; *As the code says* takes it away.
  `POST /api/modules/default`.
- *Upload it* for another version needs no version typed - the file says its
  own; once checked, the file is named by its kind and version
  (`netscaler_14_1.py`), not by the name of the file brought
  (`netscaler_14_1 (1).py` became `netscaler_14_1__1_.py`).

## 1.0.34 - 2026-11-03

- /etc/acme/plugins: install.sh makes `checks/` too (tests of your own had no
  folder), and writes `README` (where modules come from, which one wins, how
  they are kept on both nodes and in backups) and `examples/` again at every
  install - working examples as `*.py.example`, not loaded: a new target,
  another version of a shipped target, an override, a new test, a version of a
  validation and of a source (each loaded by test/test_plugin_examples.py).
  docs/writing-a-module.md: *Where modules come from, and which one wins*, in a
  cluster and in backups. A full backup and its restore are tested with a test
  of your own on the disk, an uploaded module and a mark.

- A test's result drawn side by side: what acme keeps (both halves of a dual
  certificate) beside what the server sent - a card each, the lines that agree
  ticked, the ones that do not red (names, issuer, validity, key, SHA-256), and
  how it was reached under them. A test that fails says the same in the job's
  log (a line for each: `✗ key: acme RSA 4096 | sent EC 384`), in the event, and
  in its mail (a table *In acme / The server sent*). The cards stand level, the
  one sent in the row of the one it is set against. A key said once (RSA 4096,
  not ec-256 256). The import window: a ZIP offered, its parts apart.

- Import of a dual certificate (RSA and ECDSA of the same names): a file
  holding both halves with their keys - a PEM, a ZIP (two PFX, .crt and .key,
  folders), or the two files dropped together (rsa.pfx + ec.pfx: `more` on the
  API) - is imported as the certificate and its twin at once, the twin shown
  next to it; the other half imported into a certificate later is kept as its
  twin (the same names, the other key type - guessed, or *Kept as* in the
  window, `"as": "alt"` on the API), not as its next version, which put the
  first half away.
- A certificate's *Export* of a dual one: *both* besides the main one and its
  twin - one PEM file holding the two (with both keys in *Key and full
  chain*), which acme imports again as the pair. A PFX holds one key only.
- Settings → Certificates and TLS → *Download* of a dual certificate asks which:
  the main one, the second one beside it, or both in one PEM - it gave the main
  one only, so the second could not be had.

- Tests: a server sending the other half of a dual certificate acme keeps only
  one half of (the same names, ECDSA where acme has the RSA one) is said as
  that - "serves the ECDSA twin of this certificate ... import it as its twin,
  or set Key asked for" - not as a stranger's certificate. A test's new *Key
  asked for* (whichever, RSA, ECDSA): TLS 1.2 with ciphers of that key only, so
  a dual server sends that one.

- Modules → a module → *Download a start* asks first: only a start (a few
  lines that take the module as it is) or the whole code of a version - the
  shipped one, any of yours, or the shipped original under a replacement - its
  class already saying the version and label you named (or, for a replacement,
  the shipped version): change a line and upload it. A file of two modules
  (tls.py: tls and https) copies only the one asked for. The upload window has
  *Start from the whole code of* too.
- A shipped module replaced: its original stays listed under your replacement
  - "shipped original - replaced, not used", its own *Download this code* (the
  shipped code, not yours). Every row says *Download this code*; the
  replacement's upload button is *Upload a new replacement*; the card says what
  is in use instead of what.
- A long popup opens at its top: a box far down (the version of a module of
  your own) is not focused, so the window does not open scrolled to it.

- A name box just opened is not red yet ("it needs a name" said before anything
  was typed - a new authority, say): said once something is typed or the box is
  left; the main button is off meanwhile, as before.
- A test's window is called "Test mail-smtp" in Czech (it stayed "The test
  mail-smtp": a name with a hyphen in it). "No tag." in Czech in a form's tags.

## 1.0.33 - 2026-11-03

- Settings → Accounts: an account's role is changed in its own column - beside
  the buttons the row ran past its card. About: a node's name apart from its tag.

- A module's tags (own, uploaded, override, version, marks) look one way
  everywhere - the same height, corners and letters, apart by a gap - and in the
  "Add a …" tiles they sit in a row of their own at the bottom left.

- Import of a PEM with its key locked: the password is asked for above what was
  read (it said "no private key in the file", and asked nothing); typed in the
  file's password box, the file is read again; the key's password works for a
  key inside the file too. A key in a file of its own, dropped beside it, is
  said as "its key: …", not "no key". A wrong password says so, not "give its
  password". The read notes in Czech.
- Modules → a module: making one of your own said as two ways - another version
  beside it (named: as many as needed, each with its version and label) or the
  shipped one replaced - each "Download a start" and "Upload it". A file of your
  own starts from the shipped module, never from another uploaded one. An
  uploaded version: "Upload a new file" replaces it. The window is drawn again
  after an upload, a mark or a file taken away (it showed what was there
  before). The upload window: its parts apart. The list: every module's icon
  in one column under its heading, a stripe (your own, the row under the
  pointer) beside it, not over it.

- Import of a certificate did nothing: the Import button broke on a box of
  its window (the owner) it could not see. It imports again.
- Tests on a server over SSH: can be saved with no test chosen yet; the tests
  it runs are a table with "Add a test" under it, as a certificate's
  deployments are, not ticks.
- A certificate's Tests: a table as its Deployments - test, state, where, last
  run - its buttons under it on the left; what the server served opens from
  the row.
- Tests: switched on and off right in the list, as targets are.
- HTTPS test: "Ask over HTTP too" says that it brings the method, path, Host
  header and other headers.

- Settings → Modules: its icon in the rail; the pane as tall as the window, only
  its list scrolls (there were two scroll bars); no lede said twice. A
  module's window: its sections apart as in every other window.

## 1.0.32 - 2026-11-03

- **Tests of what the servers serve**: Certificates → **Tests** defines
  them as targets are defined - a module, its settings, *Test* - and the
  certificate's window attaches them as it deploys (*Attach a test*). A test
  connects as a client of its protocol would and compares the chain it is sent
  with the certificate: the version deployed (or an old one - the renewal did
  not reach the server - or another certificate), the names, the chain, how
  long it runs, trust here; HTTPS also asks over HTTP with its own Host header,
  path and status expected. Modules: HTTPS, TLS on any port, SMTP (STARTTLS) and
  SMTPS, IMAP / IMAPS, POP3 / POP3S, FTP (AUTH TLS) / FTPS, LDAP (StartTLS) /
  LDAPS, RDP, PostgreSQL, MySQL / MariaDB, Microsoft SQL Server (TLS in TDS),
  XMPP, MQTT, SIP and DNS over TLS - and a **connector** that signs in over SSH
  to a Linux server (the key card of an SSH target) and runs the tests chosen
  for it from there (`ssh -W`). Every setting can be set: the address connected
  to (an IP), the SNI, the name looked for, the certificate expected, TLS
  versions, ciphers, ALPN, the address family and source. Run after the
  certificate's deployments, by themselves (Settings → Renewal and notices:
  *Test the servers by themselves*, every 360 min), or now; a test that starts
  failing is an event, a mail and an SMS (Settings → Message texts: *A test of
  a server failed* / *works again*). *What happens* shows them as a phase of
  their own, one test at a time or side by side. Command line: `--tests`,
  `--check-add` … `--check-attach CERT TEST`, `--checks`, `--check-run`.
  Tests are modules as any: overridden, versioned, uploaded (docs/checks.md,
  docs/writing-a-module.md).
- **Settings → Modules** (was a tab of its own).

- **The page Modules**: every module sources, validations and targets are
  made of - shipped, your own on the disk of a node, uploaded on the page -
  with where it comes from, its versions, how many use each and its marks;
  tiles to filter by origin, the families as chips, a search box as every
  other. *Download* gives the source of any module (a shipped one to start an
  override from); *Make one of your own* a file that subclasses it; *Upload a
  module* takes a `.py` file, checks it in a process of its own and shows
  what it would add or replace before it is kept. Uploading, marking and
  taking away are a full administrator's, written to the events.
- **Versions of a module**: several classes of one kind, each with its
  `module_version` (an API version of a device); each source, validation or
  target chooses its version in its form (cards under *Settings of the
  module*), kept as `_version`; the default by `default_version`. A version
  that is gone is said in red and the default one used meanwhile. Works for
  overrides too - a shipped module without versions can get two of your own.
- **Overrides said**: a module of your own with the kind and version of a
  shipped one replaces it - tagged *override* (orange) wherever the module is
  drawn: its form, the lists, the module picker; one of your own *own module*
  or *uploaded* (violet), a version in blue.
- **Marks**: *tested* (cyan), *works* (green), *problem* (red) on a version of
  a module - set by a full administrator (also `acme --module-mark`), kept
  with the file's sha256 (a file changed since is said), and shipped with a
  release in `acmelib/plugins/verified.json` (outlined, with a shield);
  `acme --module-marks-export` writes the marks of an installation in that
  shape.
- **Modules of your own are backed up**: uploaded ones live in the database -
  in every copy and on both nodes, each node writing them into its own folder;
  the files on the disk (`/etc/acme/plugins`) are kept in the database too,
  in every copy (they were only in a full backup), compared between the nodes
  (the page warns when they differ) and written back by `acme --plugins-sync
  NODE`.

## 1.0.31 - 2026-11-03

- **NetScaler (Citrix ADC): a certkey not there yet is added.** NITRO says
  "not there" as HTTP 599 with an errorcode - `1540 Certificate does not
  exist` for `GET sslcertkey/NAME`, `258 No such resource` - where acme looked
  for 404 only, so the first deployment stopped at *reading acme-NAME: the
  device said 599 - Certificate does not exist* before anything was
  uploaded. Those two codes are read as "not there" for the certkey, its CA
  certkeys and the SSL virtual servers; any other 599 is still an error. A
  copy of the module put in /etc/acme/plugins/targets/ to get round it can be
  deleted after the upgrade (it would go on overriding the one shipped).

## 1.0.30 - 2026-11-03

- **dns-persist-01: a record at each name - a switch.** Let's Encrypt looks the
  record up only at the name it validates (Boulder, va/dns_persist.go:
  `_validation-persist.<the name>`, no look at the domains above): staging
  refused pokus.example.com - *NXDOMAIN looking up TXT for
  _validation-persist.pokus.example.com* - although
  _validation-persist.example.com with policy=wildcard was there, which the
  draft says covers every name under the domain. The new switch **A record at
  each name (Let's Encrypt today)**, off by default - turn it on for Let's
  Encrypt as it is now: each name of a certificate gets, and is checked for,
  its own `_validation-persist.NAME`
  (`policy=wildcard` covers that name and `*.NAME`); *Write the records to DNS*
  and an order write the missing ones through the chosen validation; the
  readiness check says a name without its record is not ready. Off (the
  default): the draft's way - one record of the domain covers the names under
  it, as before. "Domains with the record" is *Names with the
  record*.

## 1.0.29 - 2026-11-03

- Find the settings from the account: a failure is said in its own words
  (it showed "HTTP 200"), with every step of the job; SSLmarket orders that
  cannot be read are a note, the rest is still found.
- Finding the settings from the account on the command line and in the
  console too: `acme --source-discover NAME` (`--validation-discover`,
  `--target-discover`; `-` with `--kind` and `--set` for one not saved) shows
  what the account says beside what is set; `--fill` saves it into the
  settings left empty - nothing set is replaced, a list is chosen with
  `--set`. The console offers it in the menu of each module that has it, and
  `acme --plugin KIND` says what it asks.

## 1.0.28 - 2026-11-03

- **Find the settings from the account** (discovery): over the form of a
  source, a validation or a target, a button opens a popup that asks only the
  sign-in (an API key, a user and password, the address). acme asks the
  account's API - read-only: nothing is ordered, changed or saved - and offers
  what it found beside what the form says: values the form has none of are
  ticked, values it has otherwise are not, lists are a choice. "Fill in the
  ticked ones" puts them into the form; Save keeps them. Every field stays
  settable by hand. SSLmarket takes the product list, the orders and - from
  the last order (or the account's organisation) - the owner, contact, invoice
  data and DCV method; SSLmarket ACME its ACME keys, products and
  organisations. Other sources: their organisations, profiles, products,
  templates, CAs, mounts and roles, the account's contacts, orders to reuse
  (never picked by themselves). DNS validations: the zones the account sees,
  and zone ids, resource groups, servers and views where a module has them
  (Cloudflare, Route 53, Azure, Google Cloud, OVH, PowerDNS, Hetzner,
  DigitalOcean, Infoblox, EfficientIP...). Targets: FortiGate VDOM, F5
  partitions, PAN-OS vsys, Check Point API version and domain, FMC domain,
  Avi version, Azure resource groups, Google Cloud locations, Cloudflare
  zones, Vault KV mounts, Nutanix clusters. Modules with nothing to find show
  no button.

- **Six new DNS-01 validations**, written from the vendors' own documentation:
  Forpsi F-DNS (the paid DNS-as-a-service only - ordinary Forpsi DNS has no
  API), ISPConfig, HestiaCP, Virtualmin, froxlor and Windows DNS (PowerShell
  over OpenSSH, Remove-DnsServerResourceRecord always with -RecordData; the
  Windows flavour of the DNS server over SSH now does the same).
- **Twenty validations re-checked** against the same documentation: Hetzner
  drops the old DNS Console API (switched off in May 2026) and waits for its
  actions; GoDaddy speaks Domains API v3 with a personal access token (v1 kept
  for settings that have a key and secret); PowerDNS uses EXTEND/PRUNE from
  4.9.12 / 5.0.2; Gandi adds and removes values with PATCH; Azure DNS writes
  with the record set's etag; Cloudflare compares TXT values unquoted (a value
  could be left behind); OVH, NS1, Porkbun, Google Cloud DNS and Akamai got
  smaller fixes.
- Active24 and Websupport send the signature's time as X-Date as well (REST API
  v2 asks for it; Date stays); Active24's old API (api.active24.com) is marked
  as the old platform, no longer working. WEDOS lists only the TXT records of
  the name (row_name, rdtype - the whole zone again on an older WAPI, never
  after a refused sign-in) and gives our TXT the TTL a TXT of that name has
  already, as records of one name and type share one there.

- **New sources**, written from the vendors' own API documents: SSL.com (SWS
  API), The SSL Store (REST API) and GlobalSign MSSL (GCC SOAP API). Each
  rekeys or reissues inside an order already bought, places a new paid order
  only with "Allow new orders (paid)", has the certificate's validation put the
  documented record or file in place, downloads with the chain, revokes and
  lists the account's orders for *Import from a source*.
- Sources re-checked against the same documents: ZeroSSL orders annual
  certificates as 200 days and downloads as JSON; Venafi Cloud's EU region is
  api.eu.venafi.cloud and renewals say USER_PROVIDED_CSR; Venafi TPP sends
  Base64 and TypeName as documented; Keyfactor sends IP SANs as "ip" and its
  own revocation codes; GlobalSign Atlas lists certificates 30 days at a time.

- **Targets re-checked against the vendors' own API documents** (16 changed,
  15 confirmed): Kemp keeps a virtual service's other certificates (CertFile is
  the whole list) and stays under 30 calls in 3 s; AWS ACM refuses a renewal of
  another key type in words; Azure Key Vault can keep the certificate as
  PKCS#12 (for Application Gateway); Sophos reads its certificate list from the
  tar the XML API answers with and sets a WAF rule's HTTPSCertificate;
  OPNsense and pfSense replace in place on Force (OPNsense optionally at every
  renewal), pfSense keeps old ones still used by OpenVPN, IPsec or the captive
  portal; A10 takes its older certificate out of a client-SSL template;
  FortiGate picks a VIP's certificate field by FortiOS version (a list from
  7.4.2); Redfish posts to the action target the controller gives and says
  when a controller (HPE iLO 6) cannot take a key; vCenter takes AlreadyExists
  as served already; PAN-OS partial commits as documented; Google Certificate
  Manager warns when an in-place update changes the names.

- **Nine more targets**, written from the vendors' own API documents
  (docs/targets.md names the files and what stays less certain): Cisco FTD
  managed by its Device Manager, Cisco ASA (HTTP Interface for Automation -
  answers read for errors, as the ASA says 200 regardless), Juniper SRX (Junos
  REST API, one commit), Azure Application Gateway (PKCS#12 or a Key Vault
  secret without a version, listeners switched), ISPConfig, HestiaCP (its
  documented commands over SSH), Virtualmin, froxlor and Proxmox Backup Server.
  Not added, and why: Cisco Catalyst 9800, WatchGuard, SonicWall, Meraki,
  pfSense's API.

## 1.0.27 - 2026-11-03

- **New sources**, written only from the vendors' own API documentation
  (docs/sources.md names the files): Sectigo Certificate Manager (Admin API:
  domains validated by CNAME, TXT, HTTP file or e-mail - the record put in place
  by the certificate's validation, domains validated already skipped - a
  certificate profile from a list, collected, renewed or replaced, revoked),
  Certum (SOAP partner API: reissued inside an order, a new order only with
  "Allow new orders (paid)", TXT/CNAME at the domain or `_certum.`, or the file
  certum.txt), GoGetSSL (API v1: reissue, or a paid order when allowed; its API
  cannot revoke - an action asks to cancel the order) and Namecheap SSL (a
  bought certificate activated or reissued, a new one bought only when allowed,
  CNAME or HTTP validation). All four can *Import from a source*.
- AWS Private CA: the template is a list of the 18 end-entity templates AWS
  documents (still typeable, per certificate too). EJBCA: the CA, end entity
  profile and certificate profile are lists (the profile lists likely need
  EJBCA Enterprise; a typed name always works), and an enrollment waiting for
  approval is said as such. DigiCert downloads the certificate by its id, as
  documented. Entrust Certificate Services is not added: its public
  certificates ended on 8 September 2025.

- **Nine new targets**, written from the vendors' own API documents
  (docs/targets.md names the files and what stays less certain): Check Point
  (Management API: a server certificate as PKCS#12, HTTPS Inspection rules and
  gateway portals, publish and install-policy), VMware NSX load balancer (a new
  certificate, the virtual servers' client SSL binding switched, the old one
  deleted), Barracuda WAF (a new certificate, the services' SSL security),
  FortiWeb, FortiADC, Cisco Secure Firewall Management Center (a new Internal
  Certificate, decryption rules switched, deployed), cPanel / WHM
  (SSL::install_ssl / installssl), DirectAdmin and Plesk (into its certificate
  repository; assigned to the site by hand).
- **A deployment's form picks from a list the target fetches** (virtual
  servers, services, rules, policies) - and a value can always be typed.

- **Five new DNS-01 validations**, each written only from the vendor's own
  documentation (docs/validation.md names the files): cPanel (UAPI
  DNS::parse_zone / DNS::mass_edit_zone with the zone's serial, only our record
  removed by its line), Joker.com (DMAPI: the zone read, our line added or taken
  away, every other line untouched), Netim (REST 1.0: the exact record deleted
  by subdomain, type and value; asynchronous operations followed until done),
  Huawei Cloud DNS (record sets, AK/SK signing) and DirectAdmin
  (CMD_API_DNS_CONTROL, deleted by name and value, every change read back).
  Their zone can be loaded as a list or typed; when the list cannot be read, it
  is found by its SOA. What the documentation leaves open is listed as "Less
  certain". BlueCat and Dynadot are left out for now (their deploy call / REST
  DNS calls are not in their public documentation).

## 1.0.26 - 2026-11-02

- **Check again checks again**, and says so: in *Add a certificate* it gave back
  the answer of a moment ago, and the zones found were kept two minutes (a
  delegation just set right still showed as it was); now everything is asked
  anew, and beside the buttons a quiet line says when it was checked, how long
  ago, how long it took and how it came out.

- **A deployment taken off from its row**: beside its Edit, a button that asks
  once in a popup and takes it off (what is on the target stays there).

- **Add only adds, and issues nothing**: the certificate waits as *added, not
  issued* until *Issue now* is pressed in its window (the look right after the
  save issued it at once before).
- **A job's window, opened again**: the certificate's window has *Its running
  job* / *Its last job*, and *Last job* in the list of certificates opens it - a
  job closed while it ran was nowhere to be found.

- **Escape closes a popup at the first press**, everywhere: a help shown by the
  pointer resting on a card or a button took the first Escape, and the popup
  needed a second.

- **A certificate's own web root** (or folder, container, bucket) of an HTTP-01
  validation - *Add a certificate → Settings* - set by a full administrator
  only, as on the module itself; a certificate administrator does not see it,
  and saving the certificate keeps it as it was set. Commands, scripts and sudo
  stay the module's alone.

## 1.0.25 - 2026-11-02

- **Lists loaded from the CA, in the source's form and for each certificate in
  *Add a certificate → Settings*** (one can always be typed): the roles of a
  Vault PKI mount (LIST roles), the certificate profiles of FreeIPA
  (certprofile_find) and the certificate templates of Google CA Service
  (certificateTemplates.list).

- The directory's groups (Settings → Administrators and the teams' members):
  *narrow this list* reads `name:`, `dn~`, `about:` with its funnel too, and the
  box stays as it is while the list under it is drawn again.

- **A search box's fields open only when asked**: by the funnel at the right
  of the box (beside the clearing cross, in its colour) or Ctrl+Space - never by
  themselves, when a popup opens or something is typed; once open they follow
  what is typed. Over a word already typed, a field picked is put after it.

## 1.0.24 - 2026-11-02

- **CZECHIA.COM (ZONER)** checked against its own swagger.json: the zone is read
  (GET /api/DNS/{zone}) before a value is added or taken away, *Test* reads it
  (or lists the domains) instead of saying only a dry run can tell, and the
  TTL is at least 120 s, as the API takes (60 was sent).

- **Active24: both of its APIs**, checked against Active24's own descriptions -
  the REST API v2 (rest.active24.cz: *Test* asks /v2/check, a Service ID alone
  gives its domain by /v2/service/{id}/dns/zone, a domain missing from the
  list of services is asked for itself) and the Active24 API (api.active24.com,
  with a token - chosen under *API*).

- **Tags: sixteen colours**, ten more (teal, cyan, indigo, pink, rose, orange,
  amber, lime, brown, slate), picked from the tag itself shown in each colour.

- **Every search box reads `field:value` and offers as one types**, as Events
  and the outgoing mail did (and otp does): Certificates (`state:failed`,
  `dns:*.example.cz`, `-tag:test`, `source:"Let's Encrypt"`, `renew:no` -
  read by the daemon, the values offered counted over the certificates one may
  see), Sources, Validation and Targets (name, kind, state, use, and every
  setting of their modules as a field: `zone:example.cz`, `product:alpiro*`),
  the records of acme's DNS server, the modules to pick from, Import from a
  source and what an authority signed. `field:a,b`, `-field:x`, `field~part`,
  `*`, `>`/`<`, ranges, `(a OR b)` and NOT as everywhere; what does not read is
  said under the box. Sources and Validation have the search box beside *Add*,
  as Targets.

- **Each certificate its own settings of its source and validations** - no
  second source for each template, product or zone. *Add a certificate* has
  the step *Settings*: every setting of the chosen source and of the
  validations its names use, with what they use, and *Own* to give this
  certificate a value of its own (an AD CS template loaded from the CA, an
  SSLS.cz product, a DNS zone, a TTL...). It follows what is chosen, and the
  renewal, *What happens* and the check of what fits use it. Secrets, where
  and as whom a module signs in, and anything that runs a command or writes a
  file stay the module's (a full administrator's).

- **New sources**, each written from its vendor's own API client (the files
  are named in docs/sources.md): ZeroSSL (REST API, not ACME - CNAME, file or
  e-mail validation, revocation), CyberArk Certificate Manager Self-Hosted
  (Venafi TPP - a policy folder, renewed in place), CyberArk Certificate
  Manager SaaS (Venafi Cloud - an application and its issuing template),
  Keyfactor Command (CSR enrollment with a template and CA, Basic or OAuth)
  and Cloudflare Origin CA (for servers behind Cloudflare). All five can
  *Import from a source*; their forms load the vendor's lists (folders,
  templates, CAs, zones).
- **New validations (DNS-01)**: Hostinger, Constellix, UltraDNS (Vercara),
  Mail-in-a-Box, EfficientIP SOLIDserver, Openprovider, easyDNS, Plesk (XML
  API) and Rackspace Cloud DNS - each from the vendor's own SDK or API
  description, listed in docs/validation.md. acme adds its value beside any
  others and removes only its own; Test changes nothing.
- **New targets**, each checked against the vendor's own code, SDK, Ansible
  collection, Terraform provider or REST specification (docs/targets.md):
  Kong Gateway (SNIs repointed, dual certificates), Nginx Proxy Manager
  (proxy, redirection and 404 hosts), VMware Avi / NSX ALB (virtual services
  or the portal, dual certificates), A10 Thunder (client-SSL templates, write
  memory), Hetzner Cloud and DigitalOcean load balancers (with *List the load
  balancers*), Azure App Service (SNI bindings), bunny.net pull-zone
  hostnames, Fastly TLS (replaced in place, its activations kept) and Nutanix
  (the cluster certificate through Prism Central v4, the cluster picked from
  a list).
- A header an API sends twice (two Set-Cookie) is kept whole.
- Active24: the signed requests of its REST API v2 carry the date as RFC 3339.
  Hetzner was checked against the new Hetzner Cloud DNS API (already used).

- **Microsoft AD CS: the templates loaded from the CA.** *Template* is picked
  from the list the CA offers the user (its Web Enrollment page
  *certrqxt.asp*, read only) - in the source's form, and for each certificate
  in *Add a certificate → Settings*. One not listed (a schema 3 template) can
  still be typed: *Type it yourself…*.
- **Every list a module loads can also be typed** (*Type it yourself…*): a
  product of SSLS.cz, a server type, a template.
- Saving the wizard no longer drops a Vault role or a template set by the API: they are
  the source's settings of the certificate now (*Settings*).
- **Import from a source: each certificate set up like a new one.** After the
  import the wizard of *Add a certificate* opens for it (for several: *Set it
  up* at each, or *Set up each one*): validation, key, renewal, profile,
  deployments - everything the source supports, as for a certificate added
  there. It starts from what the certificate says (its subject, key usages
  and must-staple are kept as its profile); saving keeps the certificate in
  use as it is and makes its next renewal so. Until set up it is marked *to set
  up* in the list.

## 1.0.23 - 2026-11-02

- An upgrade added no column declared last before a table's own rule (UNIQUE):
  the certificate an own authority signs (cert_ca_issued) was not kept.
- **Import from a source** (Certificates, beside *Import*): the certificates
  your account already has at SSLS.cz, SSLmarket, DigiCert CertCentral, Vault,
  EJBCA, FreeIPA, Google CA Service, GlobalSign Atlas or an authority of acme's
  own are listed (only asked - nothing is ordered or changed there), each with
  its names, product, state, validity, what is paid and its id there, *already
  in acme* marked; the ones ticked are imported in one job with an owner, tags,
  a validation and *Renew by itself*, and the popup says what was imported,
  skipped or failed and why. Each stays bound to its source with its own id
  there: a renewal reissues that very SSLS ID or order (free while it runs; a
  new order only with *Allow new orders (paid)*) - no *Certificate to reuse*
  needed. ACME sources cannot list what they issued (docs/certificates.md).
- **Add its private key** in a certificate's window, for one acme holds no key
  of (imported from a source, or from a file without it): pasted PEM or a
  .key/.pem/.pfx/.p12 file, checked to belong to the certificate, then kept
  sealed (a dual certificate's twin too). Until then a deployment that needs the
  key is refused in those words; one that needs only the certificate works. The
  first renewal of an imported certificate makes a new key, held by acme.
- **The clocks of the nodes** (Settings → Time, the card of otp): a node whose
  clock is off refuses right codes of the second step and keeps the VIP
  address. Chosen there: *As until now* (the default - nothing of it runs),
  *Measure and warn* (each node asks the time servers itself over SNTP and
  measures the other node's clock through its database; alerts), or *Step
  aside when not well* (the node whose clock is off steps aside - no lead, no
  DNS answers, the VIP address and /healthz go to the other node - only while
  the other is well, never both). Switches: the codes, the heartbeats and the
  lead's lease, the pauses after wrong tries by the corrected time; step aside
  when the directory cannot be reached. docs/clock-guard.md.
- **When the nodes lose each other**, as otp 1.0.224-1.0.227: the report
  waits for the other node's rows to come over (10 min at most) and counts
  only this time apart, each thing once; with *Only the preferred node* the
  other node goes on when the preferred node's database refuses (PostgreSQL
  shutting down or starting up, or refusing while its machine answers), is
  in maintenance, or stepped aside for its clock; a node that steps aside is
  silent at once; and the question before a code, held off after the other
  database did not answer, is asked every 2 s again - in every mode.
- **A target switched on and off right in its list** (a switch in Targets; off
  asks first when certificates are deployed there). Its deployments are kept;
  on the Certificates list a certificate says "N target(s) off", and in its
  dialog the deployment says "target switched off" - nothing is put there until
  it is on again.
- A switch drawn on was taken as an edit of the person's: a live redraw of a list
  put it back on after it was turned off (the target's switch, and any switch
  whose value changed meanwhile).
- **Show a certificate** (Certificates, beside *Import* - for everybody, read-only
  too): drop any file or paste its text - PEM with any number of blocks, DER,
  PKCS#7 (.p7b/.p7c), PFX/P12 (modern and legacy, a Java PKCS12 keystore too),
  JKS and JCEKS keystores, a CSR, a CRL, a private or public key, base64 without
  its lines, a ZIP of them - and see everything in it in the largest popup. On
  top the chain as a rail, leaf to root: each certificate a station, the
  signature of each link checked, the root in this server's trust store or not,
  a missing issuer said; a keystore's entries by alias. Below, the one picked in
  cards over the whole width: subject and issuer by each part, validity with a
  bar, key, serial (hex and decimal), fingerprints, names, key usage and EKU,
  basic and name constraints, policies (DV/OV/EV), CRL and OCSP addresses, key
  ids, CT SCTs, must-staple, any other extension as its OID and bytes, the PEM
  to copy or download. A locked file asks for its password in the popup (a
  wrong one is said); a JKS shows its certificates even without one. A private
  key is only described - its type, whether it was encrypted, which certificate
  it fits - never sent back. Nothing is kept and nothing changes.
- **Sign a CSR** (Authorities): the request is read as soon as it is pasted or
  read from a file and shown beside the form - its subject, names, key, whether
  it is signed by its own key, the extensions it asks for - with what the
  certificate will get (the issuer, from and until with the authority's end,
  names, key usage, what it is used for). The signed certificate is shown in
  the same viewer with its chain, with *Copy* and *Download*; a CSR in DER (read
  from a file) is signed too.

- What happens with several deployments: a junction - the plan's line branches
  into a track to each deployment's station (its target, module, host, how
  many steps, whether it holds the key); the one picked is shown below over the
  whole width, "All of them" lays them out side by side. On a phone nothing of
  the plan runs wider than the screen any more.

- What happens: a PowerShell command sent as `-EncodedCommand` is shown as the
  script it runs, readable (a password written into it as dots); the encoded
  command as sent stays below, folded.

- The root helper (acme-web.service) writes in the journal each of its parts
  that takes 3 s or more (`journalctl -u acme-web.service`) - a page that waits
  on one of them shows which one held it up.

- Delete with revoke: the certificate stays in the list as "being revoked, then
  deleted" until its CA has it, and only then goes; a revocation that fails
  leaves it "revocation failed" with the reason - nothing deleted, not renewed
  or deployed by itself - with *Delete* (again, with or without revoking) and
  *Keep it* in its dialog.

## 1.0.22 - 2026-11-02

- Settings → SSH server: an error of one read ("the root helper of this node
  did not answer in 60 s", e.g. while the node was being upgraded) no longer
  stays on the node's card after the reads that worked since; a change that
  failed still stays said until one works.
- DNS-PERSIST-01: *Test* says what is still to do as numbered steps (make the
  account, write the record through the chosen validation, choose a fallback)
  and fails only when a certificate would fail - not for an account to be made
  at the first order or a CA not looked at yet.
- DNS-PERSIST-01: a record is read from the zone's own name servers first - a
  record just written read as "not in DNS yet" for up to an hour while the
  resolvers kept the "no such record" of the look before it.
- Each action of a module (a validation's, a source's, a target's) has its own
  icon in the lists - make the record, look, check, write, take away, products,
  discover… - instead of the same gear for every one.

## 1.0.21 - 2026-11-02

- An authority of acme's own keeps every certificate it signs (also a CSR
  signed by hand), so it can be imported later.

- WEDOS (WAPI) as its documentation says: the record's comment sent as
  `author_comment` (was `auth_comment`), every page of the domains (50 a page
  before - an account with more did not find its domain), only primary, active
  domains written to, 2316 ("already exists") taken as done, the rows read in
  either shape, and a refused sign-in holds every call to WAPI for 5 minutes -
  more wrong requests block the address at WEDOS.
- **acme never runs into the limits of the services it talks to**: a
  validation signs in **once** for all the certificates it covers - "What to
  set up" of a Webglobe validation with six certificates signed in six times
  and Webglobe answered *Too Many Attempts*. Sign-in tokens (Webglobe, Azure,
  Google, TransIP, Mythic Beasts, netcup, INWX) are kept for their lifetime per
  validation and settings, a refused sign-in is not tried again for a minute,
  lists of zones and a validation's test are shared for a little while (*Check
  again* right after asks nothing again). Every remote host gets at most two
  requests at once and four a second, from every job together; a `429`, `503`
  or *Too Many Attempts* is waited out (Retry-After, else a growing wait) and
  asked again only where that is safe, the host left alone meanwhile - and the
  job says so. Let's Encrypt's limits for new accounts and orders are kept.
- **Readiness lists are compact**: "6 certificates · 4 ready · 2 need
  attention" on top, what needs attention open and first, what is ready one row
  each (a click opens it), several ready ones folded into one row - in a
  validation's "What to set up", a certificate's *Check* and *Dry run* and the
  wizard. A check opened again within half a minute is not asked again.
- **dns-persist-01 writes its record itself**: *Write the record through*
  picks one of your DNS validations (Active24, Webglobe, Cloudflare, SSH
  DNS…); *Check the records* says per domain whether it is there, missing or
  another value, *Write the records to DNS* writes only what is missing (only
  acme's own older value is replaced, other records are left alone), *Take the
  records away* removes exactly what acme wrote. With *Write it by itself when
  missing* an order writes a missing record first; *What happens* shows it.
  Taking the validation away asks in a popup, with *Also remove its records
  from DNS*.
- *Take it away* in a validation's (source's, target's) own popup asks first -
  it deleted at once.
- A new deployment whose Save is refused (a field missing, a right missing) is
  no longer left behind: every failed Save added another one to the certificate.
- Saving a deployment (or a source, validation, target) no longer asks for a
  required field of a part switched off - "Folder of the store is needed" with
  the IIS Central Certificate Store role off on a Windows server.
- **Delete asks in a popup and revokes first**: *Revoke it first* is ticked
  (with the reason, "no longer used"); the certificate is revoked at its CA and
  then deleted, in one job - a revocation that fails deletes nothing. Where it
  cannot be revoked (not issued, revoked already, self-signed, no source) the
  popup says so. *Revoke* alone stays its own button.
- **SSLS.cz** (`ssls`, docs/ssls.md): a new source for the certificates SSLS.cz
  sells (AlpiroSSL, Sectigo, PositiveSSL, Certum, GeoTrust, DigiCert…) through
  its API SAPI v2. The product is picked from the list SSLS.cz gives (*Load the
  list* in the form - nothing is ordered); DCV by DNS (a CNAME, Certum a TXT) or
  FILE is put in place by the certificate's own validation and taken away
  after, DCV by e-mail needs no validation (the approver address picked from
  those SSLS.cz offers). Renewals are free reissues (`quickReissue`) while the
  subscription runs; a new order is a purchase and is made only with *Allow new
  orders (paid)* on (off by default). *Try it* checks the token and the allowed
  IP address and shows the credit. A form field can now be a list the module
  loads live (the type `catalog`).

## 1.0.20 - 2026-11-02

- *What happens*: a certificate says, step by step, everything a renewal of it
  does - the key and the request (made new or kept, the CSR sent in), every
  call to its source (the ACME protocol in order with its signed payloads, an
  authority of acme's own with the extensions it signs, any other source as
  its module calls it), how each name is proved (the record or file, the
  provider's API calls, the DNS questions, the wait, the cleanup), and for
  each deployment how acme connects (host, port, user, key or password, the
  host key pinned or not, TLS checked or not) and every call with its method,
  address and body, every file with its path, mode and size, every command,
  the check after it - what only the first time does marked, and who is told.
  A button in an opened certificate, and on the last step of Add a
  certificate - from what is set there, nothing saved. It is worked
  out by running each module's own code in a process that can reach nothing
  and change nothing: no device, DNS server or CA is contacted, no file is
  written; passwords, keys and tokens are never shown.

## 1.0.19 - 2026-11-02

- *Wrong codes before it has to be sent again* (Settings → Codes by e-mail and
  SMS) was never asked: a code of the second step sent by mail or SMS could be
  tried any number of times while it was good. It is gone after that many wrong
  tries, and another has to be sent.
- A CA certificate pasted for isemon, for syslog or for another ACME CA lost its
  line breaks in a box of one line - and was then refused when it was used; the
  records of acme's own DNS server could be given only one. These are boxes of
  several lines now.
- An account's role in Settings → Accounts waits for Save in the bar at the
  bottom, as every other change there - it was given the moment the list changed.
- Settings → Time and Upgrades no longer scroll sideways on a phone; a list
  narrower than its words there (the nodes of Upgrades) scrolls in its own box
  rather than laying one cell's tags over the next; a long message (an error
  with a path in it) or address breaks inside its box instead of running off it.
- In Czech: what a screen reader is told of a setting whose help has a name or
  an address in it, the words of *Give the disk back*, of the Teltonika check,
  of restarting PostgreSQL, of stopping a system update and *on the VIP address
  only* (DNS server) are translated.
- SSH DNS: the server nsupdate sends to is checked (one host and a port);
  Microsoft AD CS: more attributes saved as text are read line by line.
- Route 53, PowerDNS, Azure DNS and Google Cloud DNS validations write the TXT
  values at a name as a whole: two jobs at once (two certificates, or a
  certificate and a dry run) could each write over the other's value, and one
  validation failed. They now write one after another.
- A certificate administrator who changed a saved source's, validation's or
  target's settings (the API address, the host) and tried them (Test, *Try
  reaching it*, *Find out what runs there*) had them tried with the API key,
  password or TSIG kept for it - which could so be sent elsewhere. Settings not
  saved are tried with the kept secrets by a full administrator only (tried as
  saved, or with the secrets typed in again, as before).
- With debug on, the steps of a job showed each address a module asked in
  full - with the token of Duck DNS or the API key of DreamHost in it. The
  secrets in an address are shown as dots.
- Behind a NAT with a split DNS (the web server 192.168.43.17 inside, the name
  published with the public address), the check before the CA is asked held
  an HTTP-01 certificate back: here the name resolved to the private address.
  Where the validation's resolvers give private addresses only, the public view
  (Settings → DNS) is asked as well, and its answer - what the CA sees -
  counts; with the public address set, a name the internet sees elsewhere is
  no longer taken as right because it resolves to the server here.
- A commercial CA's DCV records (DigiCert, SSLmarket) put in place before an
  error other than a refusal (a broken connection, say) are taken away again.

- A backup put back that was made while a job ran no longer leaves its
  certificate busy for hours: those jobs come back marked failed.
- The key on the enrolment pages is also given to the person who asked for the
  certificate in a request profile that offers it (for a team).
- The commands a deployment runs on the target (before, test, reload, after,
  the script on the machine) are changed only by a full administrator, as the
  script written here already was; a certificate administrator keeps them.
- Running one deployment while another job works on the certificate waits for
  that job and then runs it (the other job's result was given before).
- Delete in a certificate's dialog goes once; its finished jobs go with it.
- A local folder target no longer writes its files again every time when the
  paths name the folder.
- A scoped account sees the members and addresses of its own teams only.
- The key of a certificate (a PFX) is given on the enrolment pages only to its
  owner, a member of its team who may manage it, or an administrator who sees
  all - no longer to a member who may only see it.
- A person of the directory signed in on the enrolment pages is asked about
  again every ten minutes: switched off there or no longer in the groups that
  let them in, and the sign-in ends.
- An account of the enrolment pages only could not give its second step there
  with *acme's own accounts* (portal_local) switched off - it was told it had
  none to give, and the sign-in page reloaded for good.
- A new password set for an account (Accounts, `acme --passwd`, a configuration
  read back), or its second step reset, now ends its sign-ins on the enrolment
  pages too - not only in the administration.
- A request waiting for approval, or declined, can no longer be switched to
  *renewed by itself* (on the portal or in the administration): the renewer then
  issued it, past the approval or the decline. The switch is not shown for a
  declined one.
- A certificate owned by a team is seen on the portal by the team's members
  only: a directory group or a person with the same name as the team saw it
  too - and could download its key where the PFX is offered.
- Wrong passwords of acme's own accounts on the enrolment pages count while the
  directory cannot be reached (they were given back with the 503, so guessing
  had no limit); a name typed there is cut at 190 characters, as in the
  administration.
- A request profile renamed keeps what was asked for from it (its count, the
  profile shown, a new CSR checked against it); a certificate deleted takes who
  asked for it on the portal with it.
- *Revoke* with *a new one at once* is refused, before anything is revoked, for
  a certificate issued for a CSR sent in (it needs a new CSR); the portal no
  longer shows what a CA said of a failed twin.
- A certificate administrator or read-only account kept to its teams could act
  on another team's certificate by giving its number written differently
  (" 5", 5.0), and take over another team's deployment by saving it with a
  certificate of its own; the Overview showed it every team's numbers and named
  the others' certificates in its alerts, and the list of jobs left its own out
  where they were past the first page of everybody's.
- *Renew now* (and revoking, deploying a new deployment at once) opens the job's
  log over the certificate again: the certificate drawn afresh took the log's
  place, and the log was lost.
- A revoked certificate switched off and on again (*In use*) no longer comes
  back as valid, nor a request waiting for approval (or declined) as one to
  issue - the renewer then issued it, past the approval.
- *Save and deploy now* pressed again after the deployment was refused (not
  issued yet) saves the same deployment again instead of adding a second one;
  the same in the wizard when a deployment of a new certificate is refused.
- The alias asked for in *Export* of a Java keystore is the alias in the file
  (it was always the certificate's name).
- Hints left in English on a Czech page: the name boxes of the wizard, the
  import, a self-signed certificate and a CSR, the secret boxes of the modules
  and the PKCS#12 password, *choose one…* of a new deployment, *default* of a
  file's mode, a script's arguments, a tag's meaning.
- A configuration read back into an installation that has certificates or
  authorities of its own keeps each deployment with its certificate (and what an
  authority signed, an authority's parent): a certificate given another number
  here left its deployments on whichever certificate had its number - another
  certificate was deployed there.
- A backup tried (*Try it*, after every backup, weekly) is no longer "not good"
  because a job, a sign-in or a code used once was written while its copy was
  made.
- Two nodes apart: a node stepped aside (or held back with *Renewals only on the
  preferred node*) no longer signs with acme's own authorities when a hold is
  released, a CRL is made by hand, an authority is renewed or one is made under
  another; and what only reads - the progress of a job, a copy downloaded, the
  wizard's choices, a preview, a check of the database - goes on on the node
  whose changes wait, and is not in the report as a change done on both.
- The preferred node renamed stays the preferred node; one that is not a node of
  the cluster can no longer be saved (`acme --set`, a configuration read back) -
  with *priority* both nodes then stepped aside while apart.
- *Stop* of a job left running by a node of the cluster that is gone (or was
  renamed) marks it stopped: it was asked of that node for ever, and the
  certificate stayed busy for two hours.
- `acme --job`, `--cert`, `--ca-show` and the others with a number beyond 64
  bits say there is none (a traceback on SQLite); `acme --events --limit` below 1
  is refused (every event, or the database's error).

## 1.0.18 - 2026-11-02

- *Renew now* asks first, in the administration and on the enrolment pages:
  what it does (a new certificate now, the one in use stays valid), from
  where, its key, and that it is put in place again.
- Running a deployment while a job works on the certificate gives that job to
  watch instead of an error.
- **Request profiles** (Settings → Request profiles, docs/request-profiles.md):
  kinds of certificates people may ask for on the enrolment pages with the
  source, the validation, the domains (wildcards, how many names), the key or
  their own CSR, the subject (each field not used, fixed or filled by the
  person), renewal, validity, usage, approval, owner, tags, who may use it and
  the PFX set beforehand - the person gives only the names. Each is picked from
  the catalogs and checked as it is saved. With none defined the portal asks as
  before.
- **A CSR sent in is decoded and shown first** on the portal - its subject, its
  names, key, signature (valid or not), usages - with every check against the
  profile and what the certificate will say beside what the CSR says; only a
  CSR that fits is asked for. Such a certificate holds no key: the CSR is kept
  and used again at every renewal (same key); *Send a new CSR* changes the key.
  A PFX or a deployment that needs the key is refused in words.

## 1.0.17 - 2026-11-02

- **Popups are wider on a wide screen**: every popup grows with the window -
  about two thirds to three quarters of it on a big screen (a certificate's
  details 1480 px at 2000 px), never the whole of it; below 1400 px as before,
  on a phone the whole width.

## 1.0.16 - 2026-11-02

- **A team's rights work on the enrolment pages**, not only in the
  administration: *manage* gives *Renew now*, renewed by itself on/off and
  *Revoke* in the certificate's dialog; *approve* (or *manage*) gives *Approve*
  and *Decline* of the team's waiting requests. The dialog says what the person
  may (*You may*), the list says *team X* for a team's certificate.
- *Ask for a certificate* is shown dimmed, with the reason, to whoever may ask
  for a team while the enrolment pages do not say yet which names and sources
  may be asked for (before: missing). Owners and teams says so too.

## 1.0.15 - 2026-11-02

- The enrolment pages no longer go blank while *Certificates on the portal* is
  off: they say that certificates are not offered yet and where the
  administrator switches them on. Settings → Owners and teams says the same
  (the members would see nothing there), with a button to the setting.

## 1.0.14 - 2026-11-02

- **A role for the enrolment pages only** ("enrolment pages only"): an account
  that never gets into the administration, signs in on the enrolment pages and
  sees and asks for what its teams give it (Owners and teams). For acme's own
  accounts (Accounts → role) and from the directory (*Group of
  enrolment-only accounts*, picked with *Find the groups*). Settings → The
  enrolment pages → *Accounts of the role Enrolment pages only may sign in*
  (on). Its first password - and any later one - is changed on the enrolment
  pages.
- **Split brain protection** for a cluster of two, as otp's: what each node
  does when it cannot reach the other (step aside, an arbiter, the preferred
  node, renewals only there, half the tries, frozen changes, the report of
  what was done apart). Default: as until now, nothing runs.
- **Validation over SSH straight on the DNS server** (BIND, PowerDNS, Knot,
  NSD, dnsmasq, Unbound, Windows): *Find what runs there* only reads, and
  fills in the server, the zones, the keys - every field stays editable.
- A certificate's details are first, with *Change*: what can be changed without
  a new certificate is said, the wizard marks the steps that make one.

## 1.0.13 - 2026-11-01

- The line on a target's form saying where files, script and roles are set is
  as quiet as the help under a field (small, dimmed), not a bright paragraph.

## 1.0.12 - 2026-11-01

- The form of an SSH, Windows or local target says where its files, their
  format, the script after them and (Windows) the roles of the server are set:
  in each certificate's deployment ("Deploy it on a target").

## 1.0.11 - 2026-11-01

- The self-signed and the CSR dialogs pick the owner and the tags from Settings
  → Owners and teams too (a certificate administrator limited to their teams
  makes certificates there as well).

## 1.0.10 - 2026-11-01

- **Deployment designer** (SSH, Windows, this machine): the files on the target
  by quick layouts or rows - format in plain words, path with {name} {cn}
  {service} {date} {alt}, mode, owner; the PKCS#12/keystore password none, set,
  or made by acme (24 characters, sealed, the same across renewals); after the
  files a script already on the machine, or written here - uploaded on every
  deployment, run with ACME_* variables (ACME_FILE_KEY_PEM, ACME_PASSWORD,
  ACME_NAMES ...), then deleted; the previous files put back when it fails. A
  live preview of the real paths and the variables, and a dry run
  (ACME_DRY_RUN=1, files into a temporary folder). Only a full administrator
  changes a script.
- **Windows roles**: RDS (Connection Broker), RD Gateway, AD FS, Web Application
  Proxy, SQL Server, LDAPS, WinRM HTTPS, SSTP VPN, IIS Central Certificate Store,
  IIS FTP, Exchange (every service), Skype for Business, SharePoint SE (beta),
  Windows Admin Center; read on the key for accounts; Test says which roles a
  server has; the PowerShell shown before it runs.
- **Owners and teams, a tag catalog, rights**: owners and teams with members
  (acme's accounts, directory users and groups) and rights (view, request,
  manage, approve); tags with a colour; nothing typed as free text any more.
  Full administrators always see and do everything; certificate administrators
  and read-only accounts see everything unless that is switched off (then only
  their teams'). Expiry and failure mails also to the team's address.
- **A certificate's details edited without a new certificate** (owner, tags,
  note, renewal, reuse of the key, name, on/off); after changed names or key
  "renew now, or at the next renewal?".
- **The certificate portal**: acme's own accounts may sign in (with their
  second factor); administrators see every certificate, others what is theirs
  or their team's.
- **Certificates from acme**: the card as in ai, every change through the save
  bar.
- **Backups**: modules of your own (/etc/acme/plugins) in them; a cluster's
  backup put back says the exact steps to make it two again; a test proves a
  backup on a clean installation is the installation it came from.
- **Czech everywhere**: every message of the daemon shown in the pages.

## 1.0.9 - 2026-11-01

- **Columns of a list no longer jump** when it is drawn again - a switch in a
  row, the auto refresh, "2 min ago" become "3 min ago": the widths it had
  first are kept (as shares, so a window made wider or narrower still fits);
  a long word that does not fit is laid out once more before the page is
  painted. A layout set by hand (the columns editor) comes first.
- **Add and issue now** shows the job already issuing a new certificate (the
  look starts it as soon as it is saved) instead of "a job is working"; the
  popup closes whatever the issuing says. "Renew now" on a certificate being
  worked on shows that job too.
- HTTP-01 over SSH guide: a CNAME to the name that has the public address is
  suggested, or a redirect of /.well-known/acme-challenge/ from another web
  server; a name acme's own block adds by itself is not a thing to set up.

## 1.0.8 - 2026-11-01

- **acme-dns: Register an account** from the validation's form - one, or one a
  name into "Accounts by name" (an acme-dns account keeps two TXT values), with
  the CNAMEs to put into your DNS; nothing saved until Save.
- SSLmarket: the DCV records of an order that waited across the upgrade to
  1.0.5 are taken away too.
- Tests: the HA and database move suites run against real PostgreSQL and
  MariaDB again; the SSLmarket suite runs all its tests.

## 1.0.7 - 2026-11-01

- **The QR code of the second factor is right again.** 1.0.6 drew it wrong:
  a helper of acme push had the name of the QR code's own (the engine's parts
  share one namespace), so an authenticator app could not read a new QR code.
  Every name is defined once now, and the engine's lint and a test say so.
- A second `db_trouble` (the words for an unreachable PostgreSQL when joining
  a cluster) renamed `ha_db_trouble` - it had taken the place of the one that
  tells a database error.
- docs/acme-push-protocol.md: **additive only** - every existing way of
  managing certificates in an application stays as it is; acme push is off by
  default and only one more way in.

## 1.0.6 - 2026-11-01

- **acme push - certificates for our other applications** (otp, isemon,
  zigmon and acme itself): a target that pairs with the application once
  (a one-time code shown there, Settings → Certificates and TLS →
  "Certificates from acme"), then installs each certificate and its renewals
  with signed requests, the private key sealed to the application.
  **Discover** reads the application's certificate slots (each node, the VIP
  address, zigmon's front server and broker) and makes the certificates and
  deployments for those not covered. The receiving side is in the engine;
  docs/acme-push-protocol.md is the specification for the other projects.
- HTTP-01 over SSH **behind NAT**: the guide never suggests a private address
  (the public one, from a name it knows); "Public addresses (NAT, load
  balancer)"; port 80 checked with the name; a name nginx does not answer said
  as such; the name validated added to acme's own block.
- Settings → DNS: **Public is built in** - always there, changed, never deleted.

## 1.0.5 - 2026-11-01

- **HTTP-01 on web servers over SSH where nginx answers port 80 already**:
  "Prepare the hosts" puts one line, `include
  /etc/nginx/snippets/acme-challenge.conf;`, at the top of each port-80 server
  block - nothing else in them changes (a certbot redirect to HTTPS goes on as
  before). Every file is checked unchanged since it was read, copied to
  /var/backups/acme-nginx/, and put back when nginx -t fails. With names
  given and no block answering them, acme's own block listens for those
  names only (not the default server). "I put it in myself": "Download the
  nginx config" gives the file and the line, and Prepare only checks.
- "Set nginx up by itself" (before Test and every validation) and "Open port
  80 in their firewall" (firewalld, ufw); a port 80 closed by the firewall is
  said as such ("No route to host" while SSH works).
- The check before the CA is asked can be made **at other addresses** - a load
  balancer, the public IP, NAT; https:// too - with the certificate's name as
  Host and SNI; "Name for Test".
- **Try reaching it fills in the host keys** of the form (every form with an SSH
  key); a different key pinned already is shown with a warning and "Replace
  with the key seen", never replaced by itself. Kept by Save.
- **Webglobe**: DNS-01 validation (login + API key; only the record it made is
  taken away) and a target uploading your own certificate to a hosted domain.
- The nginx config for HTTP-01 printed by `acme --validation-action NAME
  nginx_files`.
- Settings → DNS: a function's set waits for Save on the bar (Put back undoes
  it); Test of a set opens over its form and gives the form back as it was.
- High security: a refused exception switch turns back instead of an error.

## 1.0.4 - 2026-11-01

- **Renewal by itself switched on and off** from the list of certificates and
  from a certificate - nothing is revoked, it stays valid and deployed.
- **Revoking**: a dual certificate's both keys (ECDSA and RSA) are revoked, the
  dialog says so; "Issue a new one at once" gives a new certificate with a new
  key in the same job, deployed where the revoked one was. A revoked one has
  "Issue a new one". The old "Switch renewal off" switch did nothing - gone.
- **dns-persist-01**: one TXT record at `_validation-persist.DOMAIN`, set once,
  for any certificate of the domain (subdomains and wildcards with
  `policy=wildcard`). acme writes the exact record for each ACME account,
  checks it, and uses it as soon as the CA offers it (Google Trust Services
  does; Let's Encrypt has announced it) - a fallback validation until then.
- **What fits together is checked before the CA is asked**: names, source,
  validation, key type and twin, in one place - the wizard greys out what does
  not fit and says why; a public CA refuses single labels, .local/.test and
  private addresses.
- **SAN editor**: typed SANs (DNS, IP, e-mail, URI), the CN apart with "CN is
  also a SAN", many pasted at once.
- **DigiCert, GeoTrust, Thawte, RapidSSL** products, with domain validation by
  TXT, CNAME, HTTP file or e-mail placed by the validation; SSLmarket uses the
  same.
- **Settings → DNS**: named sets of DNS servers (UDP, TCP, DNS over TLS) given
  to validation, public checks, APIs, targets, ACME and mail; the system's by
  default.
- **Own authorities edited** without removing them: settings, the name (the old
  /pki/ addresses still served), the certificate renewed with the same key, its
  history. A switched-off authority still publishes its CRL.
- Name constraints written as "permitted DNS:…" are read too.
- SSLmarket reworked after its API description, and SSLmarket ACME.
- The authorities' tree drawn with joined lines; "until" of a CRL translated.

## 1.0.3 - 2026-11-01

- **The pages after an upgrade are the new ones**: they said otp's version
  (1.0.209) for every acme release, so browsers kept core.js and admin.js from
  before - the default buttons without their star, errors of old scripts on
  new pages after F5. Every script and stylesheet is keyed by its own file now,
  and a release keeps the pages' version equal to acme's.
- acme's own DNS server answering on the VIP only: the validation's Test and
  its wait ask the VIP, not 127.0.0.1 where the server does not listen then.
- The SQLite file's setting is on The database pane, not under every pane; a
  test keeps every setting on a pane of its own.
- A button after words on the same line keeps its gap ("… is there" [every
  step]).

## 1.0.2 - 2026-11-01

- **Validation that tells you what to do, and tests itself.** For every name of
  a certificate acme says what has to be in place and where - the exact CNAME,
  NS or TXT record with Copy buttons, where an HTTP-01 name must point - and
  checks it live. "Dry run" puts a real test record or file in place, sees it
  from outside and takes it away, without asking the CA. Names are grouped by
  domain, with a validation suggested for each (a certificate may span many
  domains, each proved its own way). Before a first certificate - and after a
  failed validation - the CA is not asked while something is missing.
- **More sources**: EST, CMPv2, HashiCorp Vault PKI, EJBCA, step-ca, AWS Private
  CA, Google CAS, FreeIPA, GlobalSign Atlas, DigiCert CertCentral, SSLmarket.cz;
  Actalis, Certum, Sectigo and DigiCert (EAB) among the ACME CAs. A paid order
  is never placed without "Allow new orders (paid)".
- **More validations** (deSEC, WEDOS, Active24, Websupport, Subreg/Gransy,
  CZECHIA.COM and some 45 more DNS providers), HTTP-01 by FTP/FTPS/SFTP, S3,
  Azure Blob and WebDAV.
- **More targets**: AWS ACM, Azure Key Vault, Google Certificate Manager,
  Cloudflare, vCenter, ESXi, Redfish (iDRAC, iLO, XCC), Sophos, Kemp, Cisco
  ISE, HAProxy (runtime API), Traefik, Caddy, NGINX Unit, Zimbra, TrueNAS,
  Docker Swarm, strongSwan, FRITZ!Box, UniFi OS.
- **Dual certificates**: ECDSA and RSA under one certificate, renewed in one
  job (the second ACME order needs no second validation) and deployed together
  where the target serves both (nginx, Apache, HAProxy, Postfix, F5, acme's own
  pages...), the variant chosen for the others.
- **acme's DNS server**: answers on the VIP address, the nodes, or both (and
  from the address it was asked at); the firewall lets it in by itself when it
  is switched on.
- **CRLs on acme**: every authority of acme's own publishes its CRL and its
  certificate over HTTP at /pki/ on every node and the VIP, refreshed by
  itself; new authorities put those URLs in what they sign.
- **The SSH key card of isemon** wherever acme signs in over SSH: make a key
  here, use your own, download, forget, try reaching it, how to set it up.
- **The database move wizard**: target, connection, checks, what happens, the
  move live, done - SQLite, MariaDB and PostgreSQL in every direction; not on a
  node of a cluster.
- A default in every list (sources, validations, targets, authorities); the
  lists are current without reloading; names made safe everywhere (the
  defaults of 1.0.0/1.0.1 are renamed with every reference to them).
- The overview as in otp: the certificates' tiles first, then the server's,
  each opening what it counts.
- Fixed: backups checked "not good" after an upgrade from the pages and with
  keys of authorities (the backups themselves were whole); the configuration's
  export left the authorities' and certificates' keys out; the encrypted link
  between the databases could not be switched on (otp's version floor).

## 1.0.1 - 2026-11-01

- **High availability: joining does everything by itself, on both sides.**
  - The node a bundle is made for is let through the firewall of the first
    node at once (for a day, until it has joined; a firewall change on trial
    never takes it back), and the joining node opens its own firewall to the
    first one before it reaches the database or copies anything - acme's own
    chain (ACME-IN) and firewalld alike, each opening checked and said
    truthfully ("does NOT let ..." with the command, when it did not work).
  - The bundle made on the pages prepares PostgreSQL on the first node as
    `acme --ha-setup` does: it listens on the node's address, the joining
    node is in pg_hba.conf, PostgreSQL is restarted - each step shown.
  - A node's PostgreSQL lets in its own address too: the replicated join
    stopped half way on "no pg_hba.conf entry for host <own address>".
  - Every failure of a join is named with its fix: connection refused (not
    listening there), timed out / no route (a firewall), pg_hba, password,
    name. "Check from here" tries it before joining. A half-done join is said
    to be one, and running it again finishes it cleanly.
  - Shared mode writes `ha_mode` on both nodes (they ran as two single
    servers on one database).
  - `--ha-status` and the page saw the outgoing replication as missing while
    both directions ran (the slots were looked for under otp's names); the
    cluster counted as unhealthy for /healthz?check=all and the alerts.
  - The Make the bundle and Join a cluster popups redrawn: a drop zone and
    what the bundle holds, the passphrase checked as typed, live steps.
- **Secrets as otp shows them, everywhere**: a stored password is dots and
  its last two characters to a full administrator, dots only to everybody
  else, and only dots while it is typed - the certificate manager's sources,
  validations, targets and deployments included. The SSH keys of validations
  and the acme-dns accounts are sealed now; the configuration export carries
  module secrets only when it is locked with a password.
- **Czech everywhere**: every tab, settings pane, popup and module form of
  the certificate manager, the job steps and the errors.
- No browser dialogs: the contact e-mail of the ACME sources is asked in
  acme's own popup.
- As in otp: "The enrolment pages" keeps its name; the balancer's health
  check offers "+ DNS server listening" (`/healthz?check=dns`) where otp
  offered RADIUS; the certificate manager's retention is on The database.

## 1.0.0 - 2026-11-01

The first version of **acme**: certificates kept, renewed and put in place by
themselves.

acme is built on the engine of **otp 1.0.209** (the one-time password server):
its platform - settings, the database (SQLite, MariaDB, PostgreSQL), sealed
secrets, the two-node cluster with its VIP address, mail and SMS, backups, the
firewall, the network, time, upgrades, the API, the command line and the
console - taken over, renamed `otp` → `acme` everywhere, and the single
`otp.py` split into a package. RADIUS, the tokens and the enrolment of otp
are not part of acme.

- **The certificate manager** (`acmelib/certs`): certificates kept with every
  version they had, renewed before they run out (or when the CA says so, ARI),
  deployed to every place they are used, one node at a time in a cluster, every
  step of every job written down.
- **Issuers**: ACME (Let's Encrypt and any ACME CA), acme's own certificate
  authorities (root and intermediate, CRLs), self-signed, Microsoft AD CS,
  SCEP.
- **Challenges**: DNS-01 with acme's own DNS server (UDP and TCP 53), RFC 2136,
  and the APIs of Cloudflare, Route 53, Azure, Google Cloud, Hetzner, OVH,
  DigitalOcean, PowerDNS and others; HTTP-01 here (nginx → `acme.php` on
  port 80) or on another web server over SSH.
- **Targets**: Linux and Windows over SSH, F5, NetScaler, MikroTik, FortiGate,
  Palo Alto, pfSense, OPNsense, Proxmox, Synology, Kubernetes, Vault, a
  webhook, and more - and your own modules in `/etc/acme/plugins/`.
- **The layout**: `acme.py` (the launcher) and `acmelib/` (the engine in
  numbered parts, the certificate manager, the modules, colorama carried
  along).
- **Python 3.14 and PHP 8.3** from the start: install.sh installs or requires
  `python3.14` (AppStream on EL, the deadsnakes PPA on Ubuntu) and PHP-FPM
  8.3, and refuses an older Python unless `--python PATH` says otherwise.
- **The installed tree**: `/usr/local/lib/acme/versions/X.Y.Z-STAMP/`, compiled,
  with `current` switched to a new one in a single step on an upgrade and the
  one before kept as `previous` (`acme_upgrade.py --previous` puts it back).
- **Releases**: `tools/release.py` builds `release/acme-X.Y.Z.tar.gz` - the
  tree with a MANIFEST of SHA-256 sums signed with Ed25519 by acme's own release
  key (`deploy/release-keys/acme-release-1.pub`; otp's key is not trusted) -
  keeps the last ten, and writes `release/index.json` and `release/LATEST`,
  which the servers read for new versions (`upgrade_url`).
