# -*- coding: utf-8 -*-
from __future__ import annotations
# ---------------------------------------------------------------------------
# The API the web pages ask
# ---------------------------------------------------------------------------
# On 127.0.0.1 only, and only for whoever holds the token in /run/acme - which
# is the web server's group and nobody else. The PHP pages relay to it and
# add nothing: the session travels as a header, and this decides what that
# session may have. Two kinds of session: an administrator's (`admin`) and a
# person signed in to the enrolment pages (`portal`), which reaches only what
# a route of those pages gives it.

ROLE_RANK = {'portal': 0, 'readonly': 1, 'certadmin': 2, 'fulladmin': 3}


class ApiError(Exception):
    def __init__(self, status, words, detail='', extra=None):
        Exception.__init__(self, words)
        self.status = status
        self.detail = detail
        # Keys of the answer besides its words (1.0.114): {'code': 'card'} of a 423.
        self.extra = extra or {}


def is_taken_already(e):
    """Whether an error is a unique key of the database refusing a second row (hunt w6):
    SQLite's IntegrityError "UNIQUE constraint failed", PostgreSQL's UniqueViolation, MariaDB's
    1062 "Duplicate entry"."""
    if not any(c.__name__ == 'IntegrityError' for c in type(e).__mro__):
        return False
    said = str(e)
    return bool(re.search(r'UNIQUE constraint|duplicate key|Duplicate entry|\b1062\b', said)) or \
        type(e).__name__ == 'UniqueViolation'


def api_token(make=False):
    if make:
        RUN_DIR.mkdir(parents=True, exist_ok=True)
        token = secrets.token_urlsafe(32)
        write_replacing(TOKEN_FILE, token + '\n', 0o640)
        try:
            import grp
            gid = grp.getgrnam(WEB_GROUP).gr_gid
            os.chown(str(TOKEN_FILE), -1, gid)
            os.chmod(str(RUN_DIR), 0o750)
            os.chown(str(RUN_DIR), -1, gid)
        except (KeyError, OSError, ImportError):
            pass
        return token
    try:
        return TOKEN_FILE.read_text().strip()
    except OSError:
        return ''


def _int_id(v):
    """An id from a request: a whole number, or ValueError said plainly."""
    try:
        return int(v or 0)
    except (TypeError, ValueError):
        raise ValueError('an id is a number')


BODY_WORDS = ('name', 'to', 'mail_to', 'dest', 'note', 'code', 'password', 'passphrase', 'lang',
              'kind', 'action', 'mail_fmt', 'display', 'user', 'old', 'new', 'again', 'q',
              'state', 'via', 'mode', 'fingerprint', 'label')


def _no_constant(word):
    raise ValueError('%s is not a number' % word)


class _HeadClock(object):
    """The request's reader, its lines read against the head's deadline while there is one
    (ApiHandler.head_s): a byte at a time trickled in no longer keeps a line - and the
    connection - going past it. Everything else is the reader's own."""

    def __init__(self, f, h):
        self._f = f
        self._h = h

    def __getattr__(self, name):
        return getattr(self._f, name)

    def readline(self, limit=-1):
        end = self._h._head_end
        if end is None:
            return self._f.readline(limit)
        out = bytearray()
        while limit is None or limit < 0 or len(out) < limit:
            left = end - time.monotonic()
            if left <= 0:
                raise TimeoutError('the head of the request took too long')
            self._h.connection.settimeout(left)
            got = self._f.peek(1)           # at most one read of the socket
            if not got:
                break
            i = got.find(b'\n')
            n = i + 1 if i >= 0 else len(got)
            if limit is not None and limit >= 0:
                n = min(n, limit - len(out))
            out += self._f.read(n)
            if out.endswith(b'\n'):
                break
        return bytes(out)


class ApiHandler(BaseHTTPRequestHandler):
    server_version = 'acme'
    protocol_version = 'HTTP/1.1'
    # A connection that says nothing for a minute is closed (1.0.101): each
    # held a thread for ever, and any program on this machine could open
    # thousands without the key.
    timeout = 60
    # The whole head of a request - its first line and its headers - within this many seconds
    # (hunt w7): `timeout` is for each read, so a byte every 50 s kept a connection, and its
    # thread, for ever - 256 of them (ApiHttpServer.MOST) and the pages had no API at all. The
    # pages send their whole head at once. From the connection's start for its first request;
    # for one more on a kept-alive connection, from its first byte (waited for `timeout`).
    head_s = 15
    # ...and the body of a request answered without reading it, read and dropped within this.
    drop_s = 30
    # ...and a kept-alive connection that asked without the key, open this long at most.
    keyless_s = 45

    # No Python version on the daemon's answers (hunt w7): "Server: acme", nothing more.
    def version_string(self):
        return self.server_version

    def setup(self):
        BaseHTTPRequestHandler.setup(self)
        self._head_t0 = self._conn_t0 = time.monotonic()
        self._head_end = None
        self._keyless = False
        self.rfile = _HeadClock(self.rfile, self)

    def handle_one_request(self):
        t0, self._head_t0 = self._head_t0, None
        if t0 is None:
            # one more request on a kept-alive connection: its first byte waited for as before
            wait = self.timeout
            if self._keyless:
                wait = min(wait, self._conn_t0 + self.keyless_s - time.monotonic())
                if wait <= 0:
                    self.close_connection = True
                    return
            try:
                self.connection.settimeout(wait)
                if not self.rfile.peek(1):
                    self.close_connection = True
                    return
            except (TimeoutError, OSError):
                self.close_connection = True
                return
            t0 = time.monotonic()
        self._head_end = t0 + self.head_s
        try:
            BaseHTTPRequestHandler.handle_one_request(self)
        finally:
            self._head_end = None

    def parse_request(self):
        try:
            return BaseHTTPRequestHandler.parse_request(self)
        finally:
            # the head is in: the body and the answer with the usual timeout
            self._head_end = None
            try:
                self.connection.settimeout(self.timeout)
            except OSError:
                pass

    def log_message(self, fmt, *args):
        if debugging('api'):
            log('api %s' % (fmt % args), 'debug')

    # ---- the plumbing ---------------------------------------------------------
    @property
    def d(self):
        return self.server.daemon

    @property
    def store(self):
        return self.server.daemon.store

    @property
    def reader(self):
        """The long lists' own connection (1.0.101)."""
        return self.server.daemon.reader()

    def client_ip(self):
        said = str(self.headers.get('X-Acme-Client') or '').strip()
        return said if re.match(r'^[0-9a-fA-F:.]{2,45}\Z', said) else self.client_address[0]

    def send_json(self, data, status=200):
        body = json.dumps(data, default=str, ensure_ascii=False).encode('utf-8')
        self.send_response(status)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Content-Length', str(len(body)))
        self.send_header('Cache-Control', 'no-store')
        self.end_headers()
        self.wfile.write(body)

    def body(self):
        if hasattr(self, '_body'):
            return self._body
        try:
            n = int(self.headers.get('Content-Length') or 0)
        except ValueError:
            raise ApiError(400, 'the length of the body is not a number')
        if n < 0:
            raise ApiError(400, 'the length of the body is not a number')
        if n > 8 * 1024 * 1024:
            raise ApiError(413, 'that is more than this takes')
        self._taken = True
        raw = self.rfile.read(n) if n else b''
        try:
            # NaN and Infinity are not numbers anybody means (1.0.103).
            self._body = json.loads(raw.decode('utf-8'), parse_constant=_no_constant) \
                if raw else {}
        except (ValueError, RecursionError):            # [[[[... too (1.0.139)
            raise ApiError(400, 'the body is not JSON')
        if not isinstance(self._body, dict):
            raise ApiError(400, 'the body is not an object')
        # What is a word is a word (1.0.103): a list where a name belongs was
        # made into the text "['x']" - an account by that name, a mail to it.
        for k in BODY_WORDS:
            v = self._body.get(k)
            if isinstance(v, (list, dict, bool)):
                raise ApiError(400, '%s is a piece of text here' % k)
            if isinstance(v, float) and k != 'code':
                raise ApiError(400, '%s is a piece of text here' % k)
        return self._body

    def body_to_file(self, path, most):
        """A request body that is a file, written down a lump at a time."""
        n = int(self.headers.get('Content-Length') or 0)
        if n <= 0:
            raise ApiError(400, 'no file arrived')
        if n > most:
            raise ApiError(413, 'that file is bigger than this takes')
        left = n
        self._taken = True
        with open(str(path), 'wb') as out:
            while left > 0:
                lump = self.rfile.read(min(left, 1 << 20))
                if not lump:
                    raise ApiError(400, 'the file did not arrive whole')
                out.write(lump)
                left -= len(lump)
        self._body = {}
        return n

    def send_bytes(self, data, name, kind='application/octet-stream'):
        self.send_response(200)
        self.send_header('Content-Type', kind)
        self.send_header('Content-Disposition', 'attachment; filename="%s"' % name)
        self.send_header('Content-Length', str(len(data)))
        self.send_header('Cache-Control', 'no-store')
        self.end_headers()
        self.wfile.write(data)

    def send_file(self, path, name):
        # Opened before a header is sent (1.0.61): a file it may not read -
        # a copy root made on the command line - went out as "200" and then
        # a 500 in the middle of the download.
        try:
            f = open(str(path), 'rb')
        except PermissionError:
            raise ApiError(403, '%s cannot be read by the service (made by root on the command '
                                'line?): chown acme:acme it, then again' % name)
        except FileNotFoundError:
            raise ApiError(404, 'there is no such file: %s' % name)
        with f:
            self._send_open_file(f, name)

    def _send_open_file(self, f, name):
        size = os.fstat(f.fileno()).st_size
        self.send_response(200)
        self.send_header('Content-Type', 'application/octet-stream')
        self.send_header('Content-Disposition', 'attachment; filename="%s"' % name)
        self.send_header('Content-Length', str(size))
        self.send_header('Cache-Control', 'no-store')
        self.end_headers()
        shutil.copyfileobj(f, self.wfile, 1 << 18)

    def do_GET(self):
        self.route('GET')

    def do_POST(self):
        self.route('POST')

    def route(self, method):
        # a request of its own: what it read of teams and roles is read again (1.0.144)
        try:
            from acmelib.certs import teams as _teams_req
            _teams_req.request_begin()
        except Exception:                               # noqa: BLE001
            pass
        try:
            self._route(method)
        finally:
            self._unread_taken()

    def _unread_taken(self):
        """The body of a request answered without reading it - refused for its token, its
        role, a switched-off sign-in (hunt w6) - read and dropped: left unread, the connection
        was closed under it and the page's relay, still sending, got a reset in place of the
        words (a file of a few hundred kB refused said only that the service did not answer)."""
        if self.__dict__.get('_taken') or '_body' in self.__dict__:
            return
        try:
            n = int(self.headers.get('Content-Length') or 0)
        except (TypeError, ValueError):
            n = -1
        if n == 0:
            return
        if n < 0 or n > 8 * 1024 * 1024:
            self.close_connection = True
            return
        # Within drop_s all told (hunt w7): read a lump at a time with the usual timeout, a body
        # trickled in by anybody without the key - refused for it - kept its thread for ever.
        end = time.monotonic() + self.drop_s
        try:
            while n > 0:
                left = end - time.monotonic()
                if left <= 0:
                    self.close_connection = True
                    return
                sock = getattr(self, 'connection', None)       # (a handler with no socket of
                if sock is not None:                           # its own: none to set)
                    sock.settimeout(min(left, self.timeout))
                lump = self.rfile.read1(min(n, 1 << 20))       # one read of the socket at most
                if not lump:
                    break
                n -= len(lump)
        except OSError:
            self.close_connection = True
        finally:
            try:
                sock = getattr(self, 'connection', None)
                if sock is not None:
                    sock.settimeout(self.timeout)
            except OSError:
                pass

    def _route(self, method):
        # A body of its own for each request (1.0.146): on a kept-alive
        # connection the handler is the same, and the last one's was read again.
        self.__dict__.pop('_body', None)
        self.__dict__.pop('_taken', None)
        url = urlparse(self.path)
        self.args = {k: v[-1] for k, v in parse_qs(url.query).items()}
        path = url.path.rstrip('/')
        self.route_path = path
        want = api_token()
        given = str(self.headers.get('X-Acme-Token') or '')
        # As bytes (1.0.149): an API key with a letter beyond ASCII raised
        # TypeError there, and the connection was dropped with a trace.
        if not want or not hmac.compare_digest(want.encode('utf-8'),
                                               given.encode('utf-8', 'replace')):
            # Kept open for keyless_s all told at most (hunt w7): a quick request without the
            # key every 59 s held a connection, and its thread, for ever.
            self._keyless = True
            if path != '/api/health':
                return self.send_json({'ok': False, 'error': 'not this API’s token'}, 403)
        fn = ROUTES.get((method, path))
        if not fn:
            return self.send_json({'ok': False, 'error': 'no such endpoint: %s %s'
                                   % (method, path)}, 404)
        # A sign-in viewing as a member (1.0.138, docs/teams.md "View as"): every write refused.
        if self.headers.get('X-Acme-Session'):
            from acmelib.certs import viewas as _viewas
            said = _viewas.refused(self, method, path)
            if said:
                return self.send_json({'ok': False, 'error': said, 'view_as': True}, 403)
        # Changes wait while the nodes are apart, on all but the preferred node (1.0.14,
        # split_freeze): what was changed on each half went its own way.
        if method == 'POST' and split_frozen():
            frozen = split_refuses(method, path, self._split_action())
            if frozen:
                return self.send_json({'ok': False, 'error': frozen, 'split': True}, 409)
        self._held = None
        self._failed = False
        self._guard = None
        try:
            got = fn(self)
            if got is not None:
                self.send_json(got if 'ok' in got else dict(ok=True, **got))
            if method == 'POST' and split_noting():
                self._split_noted(path)
        except ApiError as e:
            # What went wrong in detail - a domain controller's name, a bind
            # DN - only to somebody signed in (1.0.33); the rest is in the log.
            detail = e.detail if self._signed_in() else None
            if e.detail and not detail:
                log('%s %s: %s (%s)' % (method, path, e, e.detail), 'info')
            self.send_json(dict({'ok': False, 'error': str(e), 'detail': detail},
                                **getattr(e, 'extra', None) or {}), e.status)
        except (ValueError, BadSetting) as e:
            said = str(e)
            if said.startswith(('invalid literal for int()', 'could not convert string to float',
                                'cannot convert float')):
                # Python's words for a field that is not a number (1.0.103).
                said = 'a field that is a number holds something else'
            got = {'ok': False, 'error': said}
            # the field of a form it is about, and its label as said (hunt M round 3): the
            # page marks that field and says the label in its own language
            if isinstance(getattr(e, 'field', None), str) and e.field:
                got['field'] = e.field
                got['label'] = str(getattr(e, 'label', '') or '')
            self.send_json(got, 400)
        except LdapError as e:
            # The domain controller's name and its TLS - only to somebody
            # signed in (1.0.136), as an ApiError's detail is.
            if self._signed_in():
                self.send_json({'ok': False, 'error': str(e), 'detail': e.detail}, 502)
            else:
                log('%s %s: the directory: %s (%s)' % (method, path, e, e.detail), 'warn')
                self.send_json({'ok': False, 'error': 'the directory could not be asked just '
                                'now - try again in a moment', 'detail': None}, 502)
        except DbError as e:
            # Where the database is, only to somebody signed in (1.0.146).
            if self._signed_in():
                self.send_json({'ok': False, 'error': str(e)}, 503)
            else:
                log('%s %s: the database: %s' % (method, path, e), 'warn')
                self.send_json({'ok': False, 'error': 'the database cannot be reached just now '
                                                      '- try again in a moment'}, 503)
        except (TypeError, AttributeError, KeyError) as e:
            # A field of the wrong kind - null where a number goes, a list
            # where an object does (1.0.44): the request's fault, said so,
            # and the trace kept in case it was not.
            log('%s %s could not be read: %s\n%s' % (method, path, e, traceback.format_exc()),
                'warn')
            self.send_json({'ok': False, 'error': 'the request is not in the shape this '
                                                  'takes (a field of the wrong kind)'}, 400)
        except (BrokenPipeError, ConnectionResetError):
            # The page went away before its answer did (1.0.61): nothing broke.
            pass
        except Exception as e:
            # A value the database cannot keep - a number out of its range, a
            # text too long for its column (1.0.103): the request's fault.
            kind = type(e).__name__
            if kind in ('DataError', 'NumericValueOutOfRange', 'StringDataRightTruncation',
                        'InvalidTextRepresentation', 'OverflowError') or \
                    (kind == 'OperationalError' and 'out of range' in str(e).lower()):
                log('%s %s: a value the database cannot keep: %s' % (method, path, e), 'info')
                self.send_json({'ok': False, 'error': 'a value is too big or of the wrong kind '
                                                      'for the database'}, 400)
                return
            if is_taken_already(e):
                # The same thing saved twice at once (hunt w6): a double click on Add, two
                # administrators adding one name - both passed the look for the name, the
                # database's unique key refused the second. Said so, not "it broke".
                log('%s %s: saved twice at the same moment: %s' % (method, path, e), 'info')
                self.send_json({'ok': False, 'error': 'one of that name was saved at the same '
                                                      'moment - load the list again'}, 409)
                return
            log('the API broke on %s %s: %s\n%s' % (method, path, e, traceback.format_exc()),
                'error')
            # The words of the exception stay in the log (1.0.33).
            self.send_json({'ok': False, 'error': 'it broke - the reason is in the log of the '
                                                  'service (/var/log/acme/acme.log)'}, 500)
        finally:
            self._release()

    def _split_action(self):
        try:
            b = self.body()
            return str(b.get('action') or '') if isinstance(b, dict) else ''
        except Exception:                               # noqa: BLE001
            return ''

    def _split_noted(self, path):
        """A change made while apart (1.0.14, split_report): written down for the report -
        the same route and thing on both nodes is the same key."""
        if split_free_path(path, self._split_action()):
            return
        try:
            b = self.body()
        except Exception:                               # noqa: BLE001
            b = {}
        b = b if isinstance(b, dict) else {}
        what = next((str(b[k]) for k in ('id', 'cert_id', 'name', 'key', 'node')
                     if b.get(k) not in (None, '') and not isinstance(b.get(k), (dict, list))), '')
        act = str(b.get('action') or '')[:40]
        thing = path + (' ' + act if act else '') + (' #' + what[:80] if what else '')
        split_took(self.store, 'change', thing, 'change:' + hashlib.sha256(
            thing.encode('utf-8')).hexdigest()[:40])

    def _signed_in(self):
        token = str(self.headers.get('X-Acme-Session') or '')
        if not token:
            return False
        try:
            # Only a look: an error must not keep a session alive. (1.0.36)
            # An administrator past the second step only (1.0.149): a portal
            # user, or a password without its code, was told the directory's
            # and the database's addresses with every error.
            s = self.store.session_get(
                token, 'admin', int(CONFIG.get('session_idle_min') or 120) * 60, touch=False)
            if not s or mfa_pending(s):
                return False
            # ...nor one held for its card (hunt P round 3): its card out, or its page no
            # longer checking - nothing of the pages answered, the directory's and the
            # database's addresses neither (with the watch off: None, as before).
            return cl_card_due('admin', s)[0] not in ('out', 'held', 'gone')
        except Exception:                               # noqa: BLE001
            return False

    def arg(self, name, default=''):
        return self.args.get(name, default)

    def num(self, name, default, lo=0, hi=10 ** 9):
        try:
            return max(lo, min(hi, int(float(self.args.get(name, default)))))
        except (TypeError, ValueError, OverflowError):
            return default

    # ---- who is asking ----------------------------------------------------------
    def session(self, kind):
        token = str(self.headers.get('X-Acme-Session') or '')
        if kind == 'admin':
            idle = int(CONFIG.get('session_idle_min') or 120) * 60
        else:
            idle = int(CONFIG.get('portal_session_min') or 15) * 60
        return self.store.session_get(token, kind, idle)

    def me(self, role='readonly'):
        s = self.session('admin')
        if not s:
            raise ApiError(401, 'not signed in, or the sign-in has run out')
        acc = self.store.account(s['name'], checked=True)
        if not acc or acc.get('disabled'):
            self.store.session_end(self.headers.get('X-Acme-Session'))
            raise ApiError(401, 'that account may no longer sign in')
        if acc.get('source') == 'directory':
            acc = self.directory_recheck(acc)
        # Signed in with Windows, and that switched off or the keytab taken away since (1.0.99):
        # the sign-in ends - but the one of whoever did it (kept, marked).
        if krb_session_gone('admin', s, self.store):
            self.store.session_end(self.headers.get('X-Acme-Session'))
            raise ApiError(401, 'sign in again')
        # Its card taken out, the lock waiting for it (1.0.113), or its page no longer checking
        # (1.0.114, held): nothing answered but the check, whoami and Sign out - 423, code card.
        cl_card_hold(self, 'admin', s)
        s['role'] = acc['role']
        if s['role'] not in ROLE_RANK or not ROLE_RANK[s['role']]:
            # Given the role of the enrolment pages only (1.0.14) while signed
            # in here: the sign-in ends.
            self.store.session_end(self.headers.get('X-Acme-Session'))
            raise ApiError(401, 'this account signs in on the enrolment pages only, not here')
        # The second step first (1.0.125): until it is given, the sign-in may
        # do that and nothing else.
        if mfa_pending(s) and getattr(self, 'route_path', '') not in MFA_ALLOWED:
            raise ApiError(401, 'the second step of signing in is not done yet')
        # Not of the directory's people (hunt w5): their password is changed there, never here -
        # a mark set on one (a password given to it past the pages) refused them every page.
        if acc.get('must_change') and acc.get('source') != 'directory' and \
                getattr(self, 'route_path', '') not in MUST_CHANGE_ALLOWED:
            raise ApiError(403, 'change the password first')
        # Viewing as a member (1.0.138, docs/teams.md "View as"): answered as theirs, read-only.
        if isinstance((s.get('data') or {}).get('view_as'), dict):
            from acmelib.certs import viewas as _viewas
            s = _viewas.admin_session(self, dict(s, account=acc))
            acc = s['account']
        if ROLE_RANK.get(s['role'], 0) < ROLE_RANK[role]:
            raise ApiError(403, {'fulladmin': 'only a full administrator may do that',
                                 'certadmin': 'only a certificate administrator may do that'}
                           .get(role, 'that account may not do that'))
        s['account'] = acc
        return s

    def portal_link(self):
        """The enrolment pages' address, for a mail that links to them: from the
        name the pages were reached by, never from what the page sent (1.0.33)."""
        host = str(self.headers.get('X-Acme-Host') or '')
        if not re.fullmatch(r'([A-Za-z0-9.-]{1,253}|\[[0-9A-Fa-f:.]{2,45}\])(:[0-9]{1,5})?', host):
            return ''
        return 'https://%s/' % host

    DIR_CHECKED = {}
    DIR_CHECK_S = 600

    def directory_recheck(self, acc):
        """Somebody signed in from the directory, asked about again every ten
        minutes (1.0.33): switched off there, or out of every group that gives
        a role, and the sign-in ends - not hours later when it runs out. A
        directory that cannot be reached leaves them as they are."""
        name = acc['name']
        t = time.time()
        if t - self.DIR_CHECKED.get(name.lower(), 0) < self.DIR_CHECK_S:
            return acc
        ad = self.d.dirs.get(str(CONFIG.get('admin_directory') or '').lower())
        if not ad:
            self.end_all(name, 'the directory administrators sign in against is gone')
        try:
            who, how = admin_name_parts(name)
            entry = ad.find_user(who, how)
            role = None
            have = None
            # ...and the same person (1.0.51): a name given again to somebody else in the
            # directory kept the open session of the one before
            same = not acc.get('dn') or not (entry or {}).get('dn') or \
                str(entry.get('dn')).lower() == str(acc.get('dn')).lower()
            if entry and same and not entry.get('many') and not entry_unusable(entry, locked=False):
                have = ad.groups_of(entry, True)
                role = admin_role_for(have, ad)
        except Exception as e:                          # noqa: BLE001
            # Asked again in a minute, not on every click: a directory that
            # does not answer would hold each page for its whole timeout. (1.0.36)
            self.DIR_CHECKED[name.lower()] = t - self.DIR_CHECK_S + 60
            log('the directory could not be asked about %s: %s' % (name, e), 'warn')
            return acc
        self.DIR_CHECKED[name.lower()] = t
        if not role or role == 'portal':
            self.end_all(name, 'the directory no longer gives %s a role here' % name)
        if role != acc.get('role'):
            self.store.set_account(name, role=role)
            self.store.add_event('accounts', 'the directory gives %s the role %s now (was %s)'
                                 % (name, role, acc.get('role')), 'warn')
            acc = self.store.account(name)
        # ...and the groups the teams look at (hunt w4): taken out of a team's group in the
        # directory, a member kept that team's certificates until they signed in again - only
        # the role was asked again here
        groups = dir_group_list(have)
        if have is not None and groups != str(acc.get('group_list') or ''):
            self.store.set_account(name, group_list=groups)
            acc = self.store.account(name)
        return acc

    def end_all(self, name, why):
        self.store.db.run('DELETE FROM sessions WHERE kind = ? AND LOWER(name) = ?',
                          ('admin', name.lower()))
        self.store.add_event('accounts', '%s: signed out everywhere' % why, 'warn')
        raise ApiError(401, 'that account may no longer sign in')

    THROTTLE_LOCK = threading.Lock()
    THROTTLE_TIDIED = [0.0]

    def throttle(self, kind, tries, wait_min, name='', ip_tries=None, name_tries=None,
                 what='wrong passwords'):
        """A sign-in attempt, counted before the password is asked (1.0.33):
        thirty at once from one address all slipped past a count made after
        the slow check. The attempt holds a place until it is known to have
        gone well, and gives it back then. Counted per address and, more
        loosely, per name, so many addresses cannot share out the guessing
        of one password."""
        ip = self.client_ip()
        try:
            a = ipaddress.ip_address(str(ip).split('%')[0])
            if a.version == 6 and not a.ipv4_mapped:
                # One /64 is one machine's to choose from (1.0.101): counted
                # per address, each guess came from a new one.
                ip = str(ipaddress.ip_network('%s/64' % a, strict=False))
        except ValueError:
            pass
        # A place that keeps guessing blocked for a while (as otp 1.0.137): refused at once, its
        # password not looked at, no directory asked.
        # Not the load balancer itself for its sign-ins (1.0.44): without web_proxy every SSO
        # request has its address - twenty refusals and nobody signed in through it for 30 min.
        sso_box = kind == 'portal-sso' and sso_peer_ok(self.client_ip())
        if kind in GUARD_KINDS and guard_on() and not guard_trusted(ip) and not sso_box:
            self._guard = (ip, name)
            b = guard_blocked(self.d, ip)
            if b:
                raise ApiError(429, 'too many wrong sign-ins from %s: blocked for %s - %s'
                               % (ip, guard_left(b[0]), b[1]))
        keys = [(kind, ip)]
        if name:
            # Counted per person, not per spelling (1.0.44): DOMAIN\\novak,
            # novak@anything and Novak are all novak here.
            who = str(name).strip().lower()
            # "admin>person" (a test of somebody's sign-in) keeps its admin
            # (1.0.146): CORP\\novak made it novak alone, one count for all.
            # Only for those tests (1.0.147): a name typed at a sign-in is
            # never split there - a>CORP\\novak, b>CORP\\novak... was a fresh
            # count each time for novak's password.
            pre = sep = ''
            if kind in ('code-test', 'dirtry'):
                pre, sep, who = who.rpartition('>')
            who = who.split('\\', 1)[-1].rsplit('@', 1)[0].strip()
            keys.append((kind + '-name', (pre + sep + who)[:190]))
        t = clock_now('locks')          # the corrected time with clock_locks (1.0.21)
        span = wait_min * 60
        with self.THROTTLE_LOCK:
            for i, key in enumerate(keys):
                # Each limit its own where asked (1.0.103): a code typed on the
                # enrolment pages is one person's, and five typos of one
                # person locked the whole office behind its address out.
                limit = (ip_tries or tries) if i == 0 else (name_tries or tries * 4)
                fails = [x for x in self.d.login_fails[key] if t - x < span]
                self.d.login_fails[key] = fails
                info = self.d.login_info.setdefault(key, {'others': []})
                info.update(limit=limit, span=span, what=what, at=t)
                other = (str(name).strip()[:120] if i == 0 else str(ip)) if name or i else ''
                if other:
                    if other in info['others']:
                        info['others'].remove(other)
                    info['others'] = (info['others'] + [other])[-6:]
                if len(fails) >= limit:
                    raise ApiError(429, 'too many %s %s: try again in %s'
                                   % (what, 'from %s' % ip if i == 0 else 'for this name',
                                      human_span(span - (t - fails[0]))))
            for key in keys:
                self.d.login_fails[key].append(t)
            # Tidied at most every 30 s (1.0.59): past 20 000 names all still
            # waiting, every sign-in scanned the whole map under this lock.
            # Past 50 000 the oldest half goes - memory has an end.
            fl = self.d.login_fails
            if len(fl) > 20000 and t - self.THROTTLE_TIDIED[0] > 30:
                self.THROTTLE_TIDIED[0] = t
                # Kept for the longest wait of any kind (1.0.61), not this
                # kind's: a 5 min kind tidied away 15 min lockouts.
                keep_s = max(span, 6 * 3600)
                for k in [k for k, v in fl.items() if not v or t - v[-1] > keep_s]:
                    fl.pop(k, None)
                    self.d.login_info.pop(k, None)
                if len(fl) > 50000:
                    # Addresses go before names (1.0.61): many addresses must
                    # not flush the count of the one name being guessed.
                    order = sorted(fl, key=lambda k: (str(k[0]).endswith('-name'),
                                                      fl[k][-1] if fl[k] else 0))
                    for k in order[:len(fl) // 2]:
                        if k not in keys:
                            fl.pop(k, None)
                            self.d.login_info.pop(k, None)
        # Each place held on its own (otp 1.0.234): a second count in the same request took the
        # place of the first, which was then never given back - every right sign-in counted as
        # a wrong password.
        held = getattr(self, '_held', None)
        if not isinstance(held, list):
            held = self._held = []
        held.append([keys, t, False])
        return keys

    def failed(self, key, guard=True):
        """The attempt went wrong: the place it holds stays taken - that one only, when it is
        said which; every place of the request otherwise. guard=False (1.0.44): a place held on
        purpose - a code that went - is no refusal for the sign-in guard."""
        g = getattr(self, '_guard', None)
        if g and guard and guard_on():
            # One refusal of the place (as otp 1.0.137), once per request.
            self._guard = None
            try:
                guard_count(self.d, g[0], g[1])
            except Exception:                           # noqa: BLE001
                pass
        held = getattr(self, '_held', None) or []
        mine = [x for x in held if x[0] is key or x[0] == key]
        for x in (mine or held):
            x[2] = True
        if not mine:
            self._failed = True

    def _release(self):
        held = getattr(self, '_held', None)
        if not held or getattr(self, '_failed', False):
            self._held = None
            return
        with self.THROTTLE_LOCK:
            for keys, t, bad in held:
                if bad:
                    continue
                for key in keys:
                    got = self.d.login_fails.get(key)
                    if got and t in got:
                        got.remove(t)
        self._held = None


ROUTES = {}
# What an administrator who still has to change their password may do.
MUST_CHANGE_ALLOWED = ('/api/auth/password', '/api/auth/logout', '/api/auth/whoami')


def route(method, path):
    def wrap(fn):
        ROUTES[(method, path)] = fn
        return fn
    return wrap


